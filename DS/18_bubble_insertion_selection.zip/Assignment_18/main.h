#ifndef SORT_H
#define SORT_H

#include<stdio.h>

#define SUCCESS 1     //defining macro.

//function prototypes.
int insertion_sort(int *, int);

int bubble_sort(int, int *);

int selection_sort(int, int *);

void print(int *, int);

#endif
