/*
date: 7 july 2021
Assignment name:Assignment_25
Author name:Shresth kumar
Description:WAF to create hash table, to search data , to insert and delete element in hash table. Also to delete entire hash table
*/
#include "hash.h"

int insert( Hash_table_t *arr, data_t data )
{
    int key = data % SIZE;
    //1.Check data is present or not
    if(arr[ key ].data == -1 )
    {
	arr[ key ].data = data;
	return SUCCESS;
    }

    //create node and store data,link
    Hash_table_t *new  = malloc( sizeof(Hash_table_t) );

    if( new == NULL )
	return FAILURE;


    //If table is not empty
    new->index = key;
    new->data = data;
    new->link = NULL;	

    if( arr[key].link == NULL )
    {
	arr[key].link = new;
	return SUCCESS;
    }
    else
    {

	Hash_table_t *temp = arr[ key ].link;
	while( temp->link != NULL )
	{
	    temp =temp->link;
	}
	temp->link = new;

	return SUCCESS;
    }
}
