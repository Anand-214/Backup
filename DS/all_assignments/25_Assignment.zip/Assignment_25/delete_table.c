/*
date: 7 july 2021
Assignment name:Assignment_25
Author name:Shresth kumar
Description:WAF to create hash table, to search data , to insert and delete element in hash table. Also to delete entire hash table
*/
#include "hash.h"
int delete_table( Hash_table_t *arr,data_t data )
{
    int key = data % SIZE;
    //If Table is Empty
    if( arr[ key].data == -1 )
    {
	return TABLE_EMPTY;
    }

    Hash_table_t *temp = &arr[key ];
    Hash_table_t *prev;
    for( int i=0; i<SIZE; i++)
    {
	arr[i].data = -1;
	temp = arr[i].link;
	arr[i].link = NULL;		

	while( temp != NULL )
	{
	    prev = temp;
	    temp = temp->link;
	    free( prev );
	}
    }
}
