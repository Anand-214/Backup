#ifndef HASH_H
#define HASH_H

#include <stdio.h>
#include <stdlib.h>

#define SIZE 5
#define SUCCESS 0
#define FAILURE -1
#define TABLE_EMPTY     2
#define DATA_NOT_FOUND 3

typedef int data_t;
typedef struct node
{
    int index;
    data_t data;
    struct node *link;
}Hash_table_t;

//function definition for insert
int insert( Hash_table_t *, data_t  );

//function definition for delete
int delete_hash( Hash_table_t *, data_t  );

//function defintion for delete table
int delete_table( Hash_table_t *,data_t  );

//function definition for search 
int search( Hash_table_t *,data_t );

//function definition for print table
void print_table( Hash_table_t *,data_t );

#endif
