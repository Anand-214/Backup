/*
date: 7 july 2021
Assignment name:Assignment_25
Author name:Shresth kumar
Description:WAF to create hash table, to search data , to insert and delete element in hash table. Also to delete entire hash table
input:gcc /Assignment_25$ make
./main.out
Enter the option
 1.Insert
 2.Print
 3.Delete_Element
 4.Delete_Table
 5.Search
 6.Quit
Enter the choice: 1
Enter the data to insert:0
Info:Table elements is:
 0 -1 -1 -1 -1
Do you want to continue (y/n) :y
Enter the option
 1.Insert
 2.Print
 3.Delete_Element
 4.Delete_Table
 5.Search
 6.Quit
Enter the choice: 1
Enter the data to insert:1
Info:Table elements is:
 0 1 -1 -1 -1
Do you want to continue (y/n) :y
Enter the option
 1.Insert
 2.Print
 3.Delete_Element
 4.Delete_Table
 5.Search
 6.Quit
Enter the choice: 1
Enter the data to insert:2
Info:Table elements is:
 0 1 2 -1 -1
Do you want to continue (y/n) :y
Enter the option
 1.Insert
 2.Print
 3.Delete_Element
 4.Delete_Table
 5.Search
 6.Quit
Enter the choice: 1
Enter the data to insert:2
Info:Table elements is:
 0 1 2 2 -1 -1
Do you want to continue (y/n) :y
Enter the option
 1.Insert
 2.Print
 3.Delete_Element
 4.Delete_Table
 5.Search
 6.Quit
Enter the choice: 1
Enter the data to insert:4
Info:Table elements is:
 0 1 2 2 -1 4
Do you want to continue (y/n) :y
Enter the option
 1.Insert
 2.Print
 3.Delete_Element
 4.Delete_Table
 5.Search
 6.Quit
Enter the choice: 1
Enter the data to insert:6
Info:Table elements is:
 0 1 6 2 2 -1 4
Do you want to continue (y/n) :y
Enter the option
 1.Insert
 2.Print
 3.Delete_Element
 4.Delete_Table
 5.Search
 6.Quit
Enter the choice: 1
Enter the data to insert:3
Info:Table elements is:
 0 1 6 2 2 3 4
Do you want to continue (y/n) :y
Enter the option
 1.Insert
 2.Print
 3.Delete_Element
 4.Delete_Table
 5.Search
 6.Quit
Enter the choice: 5
Enter the data to search:6
Info: 6 is available in table
Do you want to continue (y/n) :y
Enter the option
 1.Insert
 2.Print
 3.Delete_Element
 4.Delete_Table
 5.Search
 6.Quit
Enter the choice: 3
Enter the data to delete: 6
Info: 6 is deleted from table
Info:Table elements is:
 0 1 2 2 3 4
Do you want to continue (y/n) :y
Enter the option
 1.Insert
 2.Print
 3.Delete_Element
 4.Delete_Table
 5.Search
 6.Quit
Enter the choice: 4
Info: All elements deleted from table
Do you want to continue (y/n) :y
Enter the option
 1.Insert
 2.Print
 3.Delete_Element
 4.Delete_Table
 5.Search
 6.Quit
Enter the choice: 6


*/
#include "hash.h"

int main()
{
    char ch;
    int option;
    int data;
    Hash_table_t arr[SIZE];

    //Creating Hash table
    for(int i=0; i<SIZE; i++)
    {
	arr[i].index = i;
	arr[i].data = -1;
	arr[i].link = NULL;
    }
    do
    {   
	printf("Enter the option\n");
	printf(" 1.Insert\n 2.Print\n 3.Delete_Element\n 4.Delete_Table\n 5.Search\n 6.Quit\n");
	printf("Enter the choice: ");
	scanf("%d", &option);
	switch(option)
	{
	    case 1:
		printf("Enter the data to insert:");
		scanf("%d", &data);
		if( insert(arr, data) == FAILURE )
		{
		    printf("Error:failed to insert \n");
		}
		print_table( arr, data);
		break;
	    case 2:
		print_table(arr, data);
		break;
	    case 3:
		printf("Enter the data to delete: ");
		scanf("%d", &data);
		if( delete_hash(arr, data) == FAILURE )
		{
		    printf("Info:Failed to delete\n");
		}
		else
		{
		    printf("Info: %d is deleted from table\n",data);
		}
		print_table( arr, data);
		break;
	    case 4:
		if( delete_table(arr, data) == FAILURE )
		{
		    printf("Info:Failed to delete\n");
		}
		else
		{
		    printf("Info: All elements deleted from table\n");
		}
		break;
	    case 5:
		printf("Enter the data to search:");
		scanf("%d", &data);
		int res = search(arr, data) ;
		if( res == SUCCESS )
		{
		    printf("Info: %d is available in table\n",data);
		}
		else if( res == DATA_NOT_FOUND )
		{
		    printf("Info: %d is not available in table\n",data);
		}
		break;
	    case 6:
		exit(1);
		break;
	    default:
		{
		    printf("Error:Invalid Option");
		}
	} 

	printf("Do you want to continue (y/n) :");
	scanf("\n%c", &ch);
    }while ( ch == 'y' || ch == 'Y' );
    return 0;
}
