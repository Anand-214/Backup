/*
date: 7 july 2021
Assignment name:Assignment_25
Author name:Shresth kumar
Description:WAF to create hash table, to search data , to insert and delete element in hash table. Also to delete entire hash table
*/
#include "hash.h"

int search( Hash_table_t *arr,data_t data )
{
    int key = data % SIZE;
    Hash_table_t *temp = &arr[ key ];

    while( temp )
    {
	if( temp->data == data )
	{
	    return SUCCESS;
	}
	temp = temp->link;
    }
    return DATA_NOT_FOUND;
}
