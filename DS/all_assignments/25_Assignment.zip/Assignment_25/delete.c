/*
date: 7 july 2021
Assignment name:Assignment_25
Author name:Shresth kumar
Description:WAF to create hash table, to search data , to insert and delete element in hash table. Also to delete entire hash table
*/
#include "hash.h"

int delete_hash( Hash_table_t *arr, data_t data )
{
    int key = data % SIZE;
    //1.If Table is Empty
    if( arr[ key].data == -1 )
    {
	return TABLE_EMPTY;
    }
    //2.If Table has only one node
    if( arr[ key]. data == data && arr[ key].link == NULL )
    {
	arr[ key ].data = -1;
	return SUCCESS;
    }
    //3.Table conatains multiple nodes but delete 1st node 
    else if( arr[ key]. data == data && arr[ key].link != NULL )
    {
	Hash_table_t *temp =  arr[ key ].link;

	arr[ key ].data = temp->data;
	arr[ key ].link = temp->link;
	free(temp);
	return SUCCESS;
    }
    //4.Table contains multiple nodes but not delete 1st node 
    else
    {
	Hash_table_t *curr = &arr[ key ];
	Hash_table_t *prev = NULL;

	while( curr )
	{
	    if( curr->data == data )
	    {
		prev->link = curr->link;
		free(curr);
		return SUCCESS;
	    }
	    prev = curr;
	    curr = curr->link;
	}
    }
}

