/*
date: 7 july 2021
Assignment name:Assignment_25
Author name:Shresth kumar
Description:WAF to create hash table, to search data , to insert and delete element in hash table. Also to delete entire hash table
*/
#include "hash.h"

void print_table( Hash_table_t *arr,data_t data)
{
    //If Table is Empty
    if( arr[ data % SIZE].data == -1 )
    {
	printf("Info:Table is empty\n");
    }
    else
    {
	printf("Info:Table elements is:\n");
	for( int i = 0; i < SIZE; i++)
	{
	    Hash_table_t *temp = &arr[i ];
	    while( temp != NULL )
	    {
		printf(" %d", temp->data);
		temp = temp->link;
	    }
	}
	printf("\n");
    }
}

