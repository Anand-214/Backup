
#include <stdio.h>
#include <stdlib.h>

//define macros

#define SUCCESS 0
#define FAILURE -1
#define ARRAYSIZE 25
#define NOELEMENT -8

//function for Iterative 
int binarySearchIterative(int arr[], int left, int right, int data);

//function for Recursive
int binarySearchRecursive(int arr[], int left, int right, int data);
void print_array(int array[], int n);
