#include "search.h"              //local header file


void print_array(int array[], int n)
{
    int i;

    for(i = 0; i < n; i++)                 //for continue operation
    {
	printf("%d ", array[i]);
    }
    printf("\n");
}

