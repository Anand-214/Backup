#include "slist.h"

//Function defination
int delete_first(Slist **head)
{
      //Create a local reference to head pointer     
      Slist *temp = *head;


      //To check whether the list is empty or not
      if(*head == NULL)
      {
           return LIST_EMPTY;	
      }

      //To check if it has only one node
      if((*head)->link == NULL)
      {
          //Free the node and update the head with NULL
	  free(temp);
	  (*head) = NULL;
          return SUCCESS;
      }

      //If list has multiple nodes
      else
      {
	
          //Update the head with next node
	  (*head) = ((*head) -> link);

	  //Delete first node
	  free(temp);
	  return SUCCESS;
      }

      return FAILURE;
} 
