#include "slist.h"

//Function defination
int delete_last(Slist **head)
{   
     //Create a local reference to head pointer
     Slist *temp = *head; 
     Slist *prev;	
	
     //To check whether the list is empty or not
     if((*head) == NULL)
     {  
          return LIST_EMPTY;
     }

     //To check if it has only one node
      if((*head)->link == NULL)
      {
          //Free the node and update the head with NULL
          free(temp);
          (*head) = NULL;
          return SUCCESS;
      }

     //If list has multiple nodes 
     else
     {
	  //Traverse through a list till last node
          while((temp->link) -> link)
          { 
               temp = temp->link;
          }

	  //Update the previous node
	  prev = temp->link;

	  //Free the previous node and free the last node
          free(prev);
	  (temp->link) = NULL;
          return SUCCESS;
     }    

     return FAILURE;
}    

