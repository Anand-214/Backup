#ifndef SLIST_H
#define SLIST_H

#include<stdio.h>
#include<stdlib.h>

#define SUCCESS      1
#define FAILURE      0
#define LIST_EMPTY   2

typedef struct slist
{
      int data;
      struct slist *link;

}Slist;      

int insert_at_first(Slist **head, int data);
int insert_at_last(Slist **head, int data);
int delete_first(Slist **head);
int delete_last(Slist **head);
int find_node(Slist *head, int index);
int delete_list(Slist **head);

#endif 
