#include "slist.h"

//Function defination
int insert_at_last(Slist **head, int data)
{
     //To create a node	
     Slist *new = malloc(sizeof(Slist));

     //To do error check
     if(new == NULL)
        return FAILURE;
     
     //To update the data and link part
     new->data = data;
     new->link = NULL;

     //To check whether the list is empty or not
     if(*head == NULL)
     {	    
        *head = new;
        return SUCCESS;	
     }

     //List is empty 
     else
     {
	//Create a local reference to head pointer     
	Slist *temp = *head;

	//Traverse through a list till last node
        while(temp->link != NULL)
	{
	     temp = temp->link;
        }
        
	//Establish a link between last node and new node
        temp->link = new;
        return SUCCESS;
     }
}     

