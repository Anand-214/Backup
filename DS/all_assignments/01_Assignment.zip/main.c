#include "slist.h"

int main()
{
    //Variables Declaration	
    Slist *head = NULL;
    int choice, data, status, index;

    //Super loop
    while(1)
    {
	 //To display choces to user and read input from user   
	 printf("1.insert_at_first\n2.insert_at_last\n3.delete_first\n4.delete_last\n5.find_node\n6.delete_list\n");
         scanf("%d", &choice);

	 //Switch case depanding on choice
         switch(choice)
	 {
	       //If choice is insert_at_first	 
	       case 1: 
	              printf("Enter the data : ");
		      scanf("%d", &data);
                      status = insert_at_first(&head, data);
		      if(status == SUCCESS)
		      {
		         printf("Node is added successfully\n");
		      }
		      else
		      {
			  printf("Failure\n");
		      }
	              break;

	       //If choice is insert_at_last 	      
	       case 2:
	              printf("Enter the data : ");
                      scanf("%d", &data);
                      status = insert_at_last(&head, data);
                      if(status == SUCCESS)
                      {
                         printf("Node is added successfully\n");
                      }
                      else
                      {
                          printf("Failure\n");    
                      }
                      break;

	       //If choice is delete_first 	      
	       case 3:
                      status = delete_first(&head);
                      if(status == SUCCESS)
                      {
                         printf("Delete_first success\n");
                      }
                      else
                      {
                          printf("Failure\n");    
                      }
                      break;

	      //If choice is delete_last 
 	      case 4:
                      status = delete_last(&head);
                      if(status == SUCCESS)
                      {
                         printf("Delete_last success\n");
                      }
                      else
                      {
                          printf("Failure\n");    
                      }
                      break;

	      //If choice is find_node	      
	      case 5:
                      printf("Enter the index");
		      scanf("%d", &index);
                      status = find_node(head, index);
                      if(status == SUCCESS)
                      {
                         printf("Node is added successfully\n");
                      }
                      else
                      {
                          printf("Failure\n");    
                      }
                      break;

             //If choice is delete_list 		      
             case 6:
                      status = delete_list(&head);
                      if(status == SUCCESS)
                      {
                         printf("Delete_list success\n");
                      }
                      else
                      {
                          printf("Failure\n");    
                      }
                      break;

             //Default case		      
             default:
		      printf("Invalid Choice");
		      printf("Please select any of the option from 1-6 \n");
		      break;

	 }
    }
}


