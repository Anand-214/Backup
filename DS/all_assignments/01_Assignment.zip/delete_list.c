#include "slist.h"

//Function defination
int delete_list(Slist **head)
{
     //Create a local reference to head pointer     
     Slist *temp = *head;
     Slist *temp2;

     //To check whether the list is empty or not
     if((*head) == NULL)
     {
          return LIST_EMPTY;
     }

     //Iterate through the list and delete till last node
     else
     {
          //Traverse through a list till last node
          while(temp)
          {
	       //Take reference to delete the node	  
	       temp2 = temp;

	       //Update the temp to next node
               temp = temp->link;

	       //Delete the node
	       free(temp);
          }
	  (*head) = NULL;
	  return SUCCESS;
     }

     return FAILURE;
}
