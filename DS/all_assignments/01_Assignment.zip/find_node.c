#include "slist.h"

//Function defination
int find_node(Slist *head, int index)
{
        //Create a local reference to head pointer     
        Slist *temp = head;

	if(temp == NULL)
	{
             return LIST_EMPTY ;
	}
        else
	{
	     //Iterate through the link till the last index value
	     for(int i = 0; i < index; i++)
	     {
	            temp = temp->link;
                    if(temp == NULL)	
		    {       
                        return LIST_EMPTY;
                    }
	     }    
	    
	     return temp->data;
	}
	return FAILURE;
}
