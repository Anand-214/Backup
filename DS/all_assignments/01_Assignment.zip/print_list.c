#include "slist.h"

void print_list(Slist *head)
{

     //Create a local reference to head pointer	
     Slist *temp = head;

     //Traverse through a list till last node and print the data
     while(temp != NULL)
     {
	  printf("%d ", temp->data);
          temp = temp->link;
     }

}     
