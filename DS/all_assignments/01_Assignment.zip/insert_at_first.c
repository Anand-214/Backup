#include "slist.h"

//Function defination
int insert_at_first(Slist **head, int data)
{
     //To create a node 
     Slist *new = malloc(sizeof(Slist));

     //To do error check
     if(new == NULL)
        return FAILURE;

     //To update the data and link part
     new->data = data;
     new->link = NULL;

     //To check whether the list is empty or not
     if(*head == NULL)
     {
        *head = new;
        return SUCCESS;
     }

     //List is empty
     else
     {

	//Establish a link between last node and new node
        new->link = *head;

	//Update head
	(*head) = new;
        return SUCCESS;
     }
}
