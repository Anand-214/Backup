
#include <stdio.h>
#include <stdlib.h>

#define SUCCESS 0
#define FAILURE -1
#define EMPTYLIST -2
#define NOELEMENT -3

typedef int data_t;
typedef struct snode
{
	data_t data;
	struct snode *link;
}SLink;

/* prints the elements in the list
 */
void print_list(SLink *);

/* insert a node at the first
 */
int insert_at_first(SLink **, data_t);

/* insert a node in the last of the list
 */
int insert_at_last(SLink **, data_t);

/* insert a node before a given node in the list if present
 */
int insert_before(SLink **head, data_t b_data, data_t n_data);


/* insert a node in the list in sorted manner
 */
int sorted_insert(SLink **head, data_t data);

/* List is changed it to be in sorted order
 */
int insert_sort(SLink **head);


/* Remove duplicates from the list and update that list
 */
int remove_duplicate(SLink **head);



int delete_element(SLink **head, data_t data);
