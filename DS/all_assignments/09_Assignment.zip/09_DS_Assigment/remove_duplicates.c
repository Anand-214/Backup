

#include "slist.h"

/* Inserts data in sorted order*/

int remove_duplicate(SLink **head)
{

		//to keep track of next next link for duplicate cases
		SLink *nextNext, *result;

		//if empty link
		if (NULL == (*head))
		{
				return EMPTYLIST;
		}


		/* take a local reference of head */
		SLink *temp, *temp2;
		temp = *head;
		temp2 = *head;

		//if single node
		if((*head) -> link == NULL)
		{
				return SUCCESS;
		}

		{
				/* if list has multiple nodes then, iterate till tail node */
				while (temp -> link)
				{
						while (temp2 -> link)
						{
								if (temp -> data != (temp2 -> link) -> data)
								{
										/* if no element is found at all then return */
										if (((temp->link)-> link ) == NULL)
										{
												return SUCCESS;
										}
										temp2 = temp2 -> link;
								}

								else
								{
										nextNext = temp -> link;
										delete_element(head, temp -> data);
										temp = nextNext;
								}

						}
						temp = temp -> link;
				}
				return SUCCESS;
		}	
		return FAILURE;
}
