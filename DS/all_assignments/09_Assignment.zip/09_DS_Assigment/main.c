/*
Name: Lokesh A Devghare
Assigment: DS_Assigment_09
Date: 07/07/2021
*/

#include "slist.h"

int main()
{
		SLink *head = NULL;
		SLink *ahead = NULL;
		SLink *bhead = NULL;

		int data, a_data, result, index;
		int choice;
		char option;
		int aListElement, bListElement, i;

		do
		{

				printf("Enter the option:\n");
				printf("1. Insert At Last\n");	
				printf("2. Insert At First\n");	
				printf("3. Display List\n");
				printf("4. remove duplicates\n");

				printf("Choice: ");
				scanf("%d", &choice);

				switch(choice)
				{
						case 1:
								printf("Enter the element to be inserted at last: ");
								scanf("%d", &data);
								result = insert_at_last(&head, data);
								(result == SUCCESS)? printf("insert_at_last SUCCESS\n"): printf("insert_at_last FAILURE\n") ;
								//check the list for validating
								print_list(head);
								break;
						case 2:
								printf("Enter the element to be inserted at First: ");
								scanf("%d", &data);
								result = insert_at_first(&head, data);
								(result == SUCCESS)? printf("insert_at_first SUCCESS\n"): printf("insert_at_first FAILURE\n") ;
								//check the list for validating
								print_list(head);
								break;
						case 3:	
								print_list(head);
								break;
						case 4:
								result = remove_duplicate(&head);
								(result == SUCCESS)? printf("remove_duplicate SUCCESS\n"): printf("remove_duplicate FAILURE\n") ;
								if (result == EMPTYLIST)
								{
										printf("List is empty\n");
										break;
								}

								//check the list for validating
								print_list(head);
								break;
						default:
								printf("Invalid entry.\n");
								break;
				}


				/* check for continue */
				printf("Do you want to Continue (y/n): ");
				scanf("\n%c", &option);

				if ( option == 'y' || option == 'Y')
				{
						continue;
				} else
				{
						break;
				}

		} while (1);

		return 0;
}
