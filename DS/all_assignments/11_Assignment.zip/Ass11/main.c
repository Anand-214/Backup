/*Name :- Lokesh A Devghare
 * Date :- 05/07/2021
 * Input :- from user
 * Output :- from user
 */

#include "stack.h"                                                     //local header file

int main()
{
	//initialize the stack
	Stack stackArray;
	stackArray.top = -1;
	int data, result;
	int choice;
	char option;
	
	do
	{

		printf("Enter the option:\n");
		printf("1. push\n");	
		printf("2. pop\n");	
		printf("3. peep\n");                                 //choice for user	
		printf("4. peek\n");	

		printf("Choice: ");
		scanf("%d", &choice);

		switch(choice)
		{
			case 1: //push data
				printf("Enter the element to be pushed onto stack: ");
				scanf("%d", &data);
				result = push(&stackArray, data);
				(result == SUCCESS)? printf("push SUCCESS\n"): printf("push FAILURE\n") ;
				if (result == STACKFULL)
				{
					printf("Stack is full\n");
				}
				break;

			case 2:  //pop data
				result = pop(&stackArray, &data);
				(result == SUCCESS)? printf("pop SUCCESS\n"): printf("pop FAILURE\n") ;
				if (result == STACKEMPTY)
				{
					printf("Stack is empty\n");
				}
				break;

			case 3: //peep operation
				result = peep(stackArray);
				(result == SUCCESS)? printf("peep SUCCESS\n  "): printf("peep FAILURE\n") ;
				if (result == STACKEMPTY)
				{
					printf("Stack is empty\n");
				}
				break;

			case 4: //peek operation
				result = peek(stackArray);
				(result == STACKEMPTY)? printf("peek FAILURE.\nStack is empty\n"): printf("peek value: %d\n", result) ;
				break;

			default:
				printf("Invalid option\n");
				break;
		}

		//check the stack for validating
		peep(stackArray);
	
		/* check for continue */
	        printf("Continue (y/n): ");
	        scanf("\n%c", &option);
        
	        if ( option == 'y' )
	        {
	            continue;
	        } 
		else
	        {
	            break;
	        }
        
	} while (1);
		
 	return 0;
}

