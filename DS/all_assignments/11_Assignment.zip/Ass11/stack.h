#include <stdio.h>                  //standard header file
#include <stdlib.h>

#define SUCCESS 0
#define FAILURE -1                  //define macros
#define STACKEMPTY -2
#define STACKFULL -3
#define STACKSIZE 25

typedef int data_t;
typedef struct
{
	int top;
	data_t Sarray[STACKSIZE];
}Stack;

//for push
int push(Stack *, data_t);
//for pop
int pop(Stack *, data_t *);
//for peep
int peep(Stack);
//for  peek
int peek(Stack);

