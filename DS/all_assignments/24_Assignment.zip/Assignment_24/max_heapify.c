#include"heapsort.h"

void swap( int *a, int *b)
{
    //swap function
    int t = *a;
    *a = *b;
    *b = t;
}

int max_heapify( int arr[],int size,int parent )
{
    //assign variables
    int left;
    int right;
    int max = parent;
    left = parent * 2 + 1; //left < size
    right = parent * 2 + 2; //right < size

    //compare max and left array and change max = left (for left branch)
    if( left < size && arr[max] < arr[left] )
	max = left;
    //compare max and right array and change max = right(for right branch)
    if ( right < size && arr[max] < arr[right] )
	max = right;
    //as max will parent in above conditions,so make not equal condition and swap array values
    if( max != parent )
    {
	swap( &arr[max], &arr[parent] );
	max_heapify( arr, size, max);
    }
} 
