#include"heapsort.h"


int print_array(int arr[], int size)
{
    //for loop to run till the last index value
    for(int i = 0; i < size; i++)
	printf(" %d", arr[i]); //print the array
    printf("\n");
}
