#ifndef HEAPSORT_H
#define HEAPSORT_H

#include<stdio.h>
#include<stdlib.h>

//function definition to print array
int print_array(int arr[],int size);

//function definition for heap sort
int heap_sort(int arr[], int size );

//function definition for max_heapify 
int max_heapify( int arr[],int size,int parent );

//function definition for swap
void swap(int *a,int*b);

#endif
