#include"heapsort.h"

int heap_sort(int arr[], int size )
{   
    //for loop from last parent to first parent
    for(int i = size/2 - 1;i >= 0; i-- )
    {
	max_heapify(arr, size, i);
    }
    //for loop to swap first(biggest) value and make last value biggest
    for( int i = size -1; i >= 0; i-- )
    {
	swap(&arr[0], &arr[i]);
	max_heapify(arr, i, 0);//apply heapify for root value
    }
}
