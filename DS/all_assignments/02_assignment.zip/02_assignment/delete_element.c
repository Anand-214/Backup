#include"slist.h"

data_t delete_element(slist_t **head, data_t data)
{
    /* to check list empty */
    if(*head == NULL)                                      
    {
	return LIST_EMPTY;
    }

    /* assigning head to temporary pointer variable */
    slist_t *temp = *head;                              

    if(temp -> data == data)
    {
	/* function calling of delete first */
	delete_first(head);                            
	return SUCCESS;
    }

    /* To traverse till NULL */
    while(temp -> link != NULL)            
    {
	if(temp -> link -> data == data)
	{
	    slist_t *temp2 = temp -> link;
	    temp -> link = temp2 -> link;
	   
	    /* freeing memory */
	    free(temp2);                         
	    return SUCCESS;
	}
	temp = temp -> link;
    }
    return DATA_NOT_FOUND;
}
