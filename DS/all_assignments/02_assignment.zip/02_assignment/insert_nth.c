#include"slist.h"

data_t insert_nth(slist_t **head, data_t d, data_t n)
{
    int c = 0;
    /* check list is empty */
    if(*head == NULL)      
    {
	return LIST_EMPTY;
    }
    slist_t *temp = *head, *temp1;

    /* check if position is first */
    if(n == 1)             
    {
	/* function calling of insert at first */
	insert_at_first(head, d);
	return SUCCESS;
    }
    while(temp -> data != 0)
    {
	c++;
	if(temp -> link == NULL)
	{
	    break;
	}
	temp = temp -> link;
    }
    if(n > (c + 1))
    {
	return NO_SUCH_SPACE;
    }
    c = 0;
    temp = *head;
    
    /* to check data */
    while(temp -> data != 0)                                 
    {
	c++;
	if(c == n)
	{
	    /* Dynamic memory allocation */
	    slist_t *new = malloc(sizeof(slist_t));   
	    new -> data = d;
	    
	    /* assigning previous link as new address */
	    new -> link = temp1 -> link;            
	    
	    /* assigning new link as next node address */
	    temp1 -> link = new;                     
	    return SUCCESS;
	}
	else if((c + 1) == n)           /* if the position is end */
	{
	    if(temp -> link == NULL)
	    {
		insert_at_last(head, d);
		return SUCCESS;
	    }
	}
	temp1 = temp;
	temp = temp -> link;  /* to change the link */
    }
}


