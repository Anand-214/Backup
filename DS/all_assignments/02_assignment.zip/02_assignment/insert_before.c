#include"slist.h"

data_t insert_before(slist_t **head, data_t g_data, data_t n_data)
{
    /* to check list empty */
    if(*head == NULL)                                         
    {
	return LIST_EMPTY;
    }
    if((*head) -> data == n_data)                                         
    {
	/* function calling of insert at first */
	insert_at_first(head, g_data);         
	return SUCCESS;
    }


    slist_t *temp = *head;

    /* To traverse till NULL */
    while(temp -> link != NULL)                                          
    {
	if(temp -> link -> data == n_data)
	{
	    /* Dynamic memory allocation */
	    slist_t *new = malloc(sizeof(slist_t));                
	    if(new == NULL)
	    {
		return FAILURE;
	    }
	    new -> data = g_data;                                 
	    new -> link = temp -> link;                             
	    temp -> link = new;                                 
	    return SUCCESS;
	}
	temp = temp -> link;
    }
    return DATA_NOT_FOUND;                                             
}
