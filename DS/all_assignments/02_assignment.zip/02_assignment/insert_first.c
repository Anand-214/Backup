#include"slist.h"

data_t insert_at_first(slist_t **head, data_t data)
{
    /* Dynamic memory allocation */
    slist_t *new = malloc(sizeof(slist_t));         

    /* check new is NULL */
    if (new == NULL)   
    {
	return FAILURE;
    }
    new -> data = data;
    new -> link = NULL;   

    /* check head is NULL */
    if(*head == NULL)       
    {
	*head = new;
	return SUCCESS;
    }
    new -> link = *head;
    *head = new;
    return SUCCESS;
}
