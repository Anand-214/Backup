#include"slist.h"

data_t insert_after(slist_t **head, data_t g_data, data_t n_data)
{
    /* to check list is empty */
    if(*head == NULL)       
    {
	return LIST_EMPTY;
    }
    /* assigning head to temporary pointer variable */
    slist_t *temp = *head;                              

    /* To traverse till NULL */ 
    while(temp != NULL)                                     
    {
	if(temp -> data == n_data)
	{
	    /* Dynamic memory allocation */	
	    slist_t *new = malloc(sizeof(slist_t)); 

	    if(new == NULL)
	    {
		return FAILURE;
	    }
	    new -> data = g_data;
	    new -> link = temp -> link;
	    temp -> link = new;
	    return SUCCESS;
	}
	temp = temp -> link;
    }
    return DATA_NOT_FOUND;
}

