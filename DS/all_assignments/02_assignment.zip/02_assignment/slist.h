#ifndef S_LIST
#define S_LIST

#define SUCCESS 0
#define FAILURE 1
#define LIST_EMPTY 2
#define DATA_NOT_FOUND 3
#define NO_SUCH_SPACE 4

#include<stdio.h>
#include<stdlib.h>

typedef int data_t;

typedef struct node
{
	data_t data;
	struct node *link;
}slist_t;

//Function prototype

data_t insert_after(slist_t **head, data_t g_data, data_t n_data);
data_t insert_before(slist_t **head, data_t g_data, data_t n_data);
data_t delete_element(slist_t **head, data_t data);
data_t delete_first(slist_t **head);
data_t insert_at_first(slist_t **head, data_t data);
data_t insert_at_last(slist_t **head, data_t data);
void print_list(slist_t *head);
data_t insert_nth(slist_t **head, data_t d, data_t n);

#endif
