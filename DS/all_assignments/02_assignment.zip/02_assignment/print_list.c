#include "slist.h"

void print_list(slist_t *head)
{
    /* Checking list is empty */
    if (head == NULL)
	printf("Error : Cannot print values, List is empty\n");
    else
    {
	/* Traversing the list and printing the values added */
	while (head)
	{
	    printf("%d -> ", head -> data);
	    head = head -> link;
	}
	printf("NULL\n");
    }
}

