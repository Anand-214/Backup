#include"slist.h"

int insert_at_last(slist_t **head, data_t data)
{
    /* Dynamic memory allocation */
    slist_t *new = malloc(sizeof(slist_t));                   

    /* check new is empty */
    if (new == NULL)                                        
    {
	return FAILURE;
    }

    new -> data = data;                       
    new -> link = NULL;                      

    /* check head is NULL */
    if(*head == NULL)                      
    {
	*head = new;
	return SUCCESS;
    }
    slist_t *temp = *head;   
    /* To traverse till NULL */ 
    while(temp -> link != NULL)
    {
	temp = temp -> link;
    }
    temp -> link = new;
    return SUCCESS;
}
