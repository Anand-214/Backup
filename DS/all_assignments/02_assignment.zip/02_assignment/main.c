/*
 * Name		  : M Supriya
 * Date		  : 02.07.2021
 * Description	  : Write a function to insert data after and before and at nth position. Also to delete given element(SLL).
 * Input & Output :	

 Entered elements: 3 -> 4 -> NULL
 Enter the position: 2
 Enter the data: 5
 The data has been inserted successfully

 Entered elements: 3 -> 5 -> 4 -> NULL
 1.insert_at_last
 2.insert_after
 3.insert_before
 4.delete_element
 5.insert_nth
 6.print_list
 7.exit
 Enter your choice: 6

 Entered elements: 3 -> 5 -> 4 -> NULL
 1.insert_at_last
 2.insert_after
 3.insert_before
 4.delete_element
 5.insert_nth
 6.print_list
 7.exit
 Enter your choice: 7

 */

#include<stdio.h>
#include"slist.h"

int main()
{
    int choice, status, g_data, n_data;
    slist_t *head = NULL;
    char ch;
    do                                                                        
    {
	/* Display menu to user */
	printf("1.insert_at_last\n2.insert_after\n3.insert_before\n4.delete_element\n5.insert_nth\n6.print_list\n7.exit\nEnter your choice: ");
	scanf("%d", &choice);                                                       

	/* switch case to perform user choice */
	switch(choice)                                                             
	{
	    case 1: /* inser last */

		printf("Enter the data to be inserted: ");
		scanf("%d", &g_data);

		/* function calling to perform operation and to print statements accordingly */
		status = insert_at_last(&head, g_data);                     

		if (status == 0)
		{	
		    printf("The data has been inserted successfully\n");
		}
		else
		{
		    printf("Error: insertion if failure\n");
		    return 0;
		}
		break;

	    case 2: /* insert after */

		print_list(head);
		printf("Enter the node data: ");
		scanf("%d", &n_data);

		printf("Enter the new data: ");
		scanf("%d", &g_data);

		/* function calling to perform operation and to print statements accordingly */
		status = insert_after(&head, g_data, n_data);                 

		if (status == 0)
		{
		    printf("The data has been inserted successfully\n");
		    print_list(head);
		}
		else if(status == 2)
		{
		    printf("List is empty\n");
		}
		else if(status == 3)
		{
		    printf("Data not found\n");
		}
		break;

	    case 3: /* inser before */

		print_list(head);
		printf("Enter the node data:\n");
		scanf("%d", &n_data);

		printf("Enter the new data:\n");
		scanf("%d", &g_data);
	printf("Enter the new data:\n");
		scanf("%d", &g_data);

		/* function calling to perform operation and to print statements accordingly */
		status = insert_before(&head, g_data, n_data);              

		if (status == 0)
		{	
		    printf("The data has been inserted successfully\n");
		    print_list(head);
		}
		else if(status == 2)
		{
		    printf("List is empty\n");
		}
		else if(status == 3)
		{
		    printf("Data not found\n");
		}
		break;

	    case 4: /* delete element */

		print_list(head);
		printf("Enter the node data: ");
		scanf("%d", &n_data);

		/* function calling to perform operation and to print statements accordingly */
		status = delete_element(&head, n_data);                     

		if (status == 0)
		{	
		    printf("The data has been deleted successfully\n");
		    print_list(head);
		}
		else if(status==2)
		{
		    printf("List is empty\n");
		}
		else if(status==3)
		{
		    printf("Data not found\n");
		}
		break;

	    case 5: /* insert nth */

		print_list(head);
		printf("Enter the position: ");
		scanf("%d", &n_data);

		printf("Enter the data: ");
		scanf("%d", &g_data);

		/* function calling to perform operation and to print statements accordingly */
		status = insert_nth(&head, g_data, n_data);

		if(status == 0)
		{
		    printf("The data has been inserted successfully\n");
		    print_list(head);
		}
		else if(status == 2)
		{
		    printf("List is empty\n");
		}
		else if(status == 4)
		{
		    printf("No such space\n");
		}
		break;

	    case 6:
		/* print list */
		print_list(head);
		break;

	    case 7: /* Exit */
		return 0;
		break;

	    default :
		printf("ERROR: IVALID OPTION!\n");
	}
	printf("Do you want to continue(y/Y) ? "); /* statement to ask continue option to user */
	scanf("\n%c", &ch);
    }while (ch == 'Y' || ch == 'y');
    return 0;
}
