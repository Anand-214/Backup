#include"slist.h"

data_t delete_first(slist_t **head)
{
    /* to check list is empty */	
    if(head == NULL)        
    {	//condition to check head is null
	return LIST_EMPTY;
    }
  
    /* assigning head to temporary pointer variable */		
    slist_t *temp = *head;                        
    *head = (*head) -> link;
  
    /* freeing tehh memory */
    free(temp);              
    return SUCCESS;
}

