

#include"slist.h"

//function for reverse a node
Slink_t *reverse_recursive(Slink_t *head)
{
		//declaring pointers
		Slink_t *temp;

		//condition to check head upto null
		if (head == NULL || head -> link == NULL)
		{
				return head;
		}

		//calling a function
		temp = reverse_recursive(head->link);

		head->link->link = head;
		head->link = NULL;

		return temp;
}
