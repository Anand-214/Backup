/*
Name:Lokesh A Devghare
Assigment: DS_Assigment_08
Date: 04/07/2021
*/

#include "slist.h"

int main()
{
		Slink_t *head = NULL;
		//Variable declaration
		int data, result;
		int choice;
		char ch;

		do
		{
				//Asking option for operation
				printf("Enter the option:\n");
				printf("1. Insert at last\n");	
				printf("2. Reverse iterative\n");
				printf("3. Reverse recursive\n");
				printf("4. Display list\n");

				printf("Enter the Choice: ");
				scanf("%d", &choice);

				switch(choice)
				{
						case 1: //function for insert_last
								printf("Enter the element to be inserted at first: ");
								scanf("%d", &data);
								result = insert_last(&head, data);
								(result == SUCCESS)? printf("%d Data is successfully entered by insert_last function\n", data): printf("Error:Data failed by insert_last function\n") ;
								//check the list for validating
								print_list(head);
								break;

						case 2: //function for reverse iterative
								{
										int result = reverse_iterative(&head);
										if (result == EMPTYLIST )
										{
												printf("List is empty\n");
										}
										else if ( result == FAILURE )
										{
												printf("Error:failed to reverse the element\n");
										}
										else
										{
												printf("The reverse elements by reverse iterative are\n");
										}
										//check the list for validating
										print_list(head);
										break;
								}
						case 3: //function for reverse recursive
								{
										Slink_t *result = reverse_recursive(head);
										if (result == NULL )
										{
												printf("Error:Failed to reverse the element\n");
										}
										else
										{
												head = result;
												printf("The reverse elements by reverse recursive are\n");
										}
										//check the list for validating
										print_list(head);
										break;
								}

						case 4: //function to print the list
								print_list(head);
								break;

						default:
								printf("Invalid entry.\n");
								break;
				}


				/* asking to repeat the function*/
				printf("\nDo you want to continue (y/n): ");
				scanf("\n%c", &ch);

				if ( ch == 'y' || ch == 'Y')
				{
						continue;
				} 
				else
				{
						break;
				}

		} while (1);

		return 0;
}
