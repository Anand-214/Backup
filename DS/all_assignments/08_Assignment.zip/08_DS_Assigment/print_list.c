
#include "slist.h"

void print_list(Slink_t *head)
{
		//take local reference to traverse through the link
		Slink_t *temp = head;

		//iterate and print 
		while(temp)
		{
				printf("%d ", temp -> data);
				temp = temp -> link;
		}
}
