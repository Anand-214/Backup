
#ifndef SLIST_H
#define SLIST_H
#include <stdio.h>
#include <stdlib.h>

#define SUCCESS 0
#define FAILURE -1
#define EMPTYLIST -2
#define DATANOTFOUND -3

/*structure definition*/
typedef int data_t;
typedef struct node
{
		data_t data;
		struct node *link;
}Slink_t;

/* prints the elements in the list*/
void print_list(Slink_t *);

/* insert a node in the last of the list*/
int insert_last(Slink_t **, data_t);

/*reverse iterative function declaration*/
int reverse_iterative(Slink_t **head);

/* reverse recursive function declaration*/
Slink_t *reverse_recursive(Slink_t *head);

#endif
