

#include"slist.h"

int reverse_iterative(Slink_t **head)
{
		//declaring pointers
		Slink_t *temp, *prev, *current;

		//check head is Null
		if (*head == NULL)
		{
				return EMPTYLIST;
		}


		//assign initial value
		current = *head;
		prev = NULL;

		//to check a condition for first node
		if (current->link == NULL)
		{
				return SUCCESS;
		}

		//loop for reverse a node
		while(current != NULL)
		{
				temp = current -> link;
				current -> link = prev;
				prev = current;
				current = temp;
		}

		//update head to prev node address
		*head = prev;

		return SUCCESS;
}
