#ifndef POSTFIX_H
#define POSTFIX_H

//header files
#include<stdio.h>
#include<string.h>
#include<stdlib.h>

#define SIZE 20

//function declaration
int compare(char symbol);

int priority(char symbol);

void infix_postfix(char infix[],char postfix[]);

float post_eval ( char postfix[]);

int my_isdigit ( char a);

#endif
