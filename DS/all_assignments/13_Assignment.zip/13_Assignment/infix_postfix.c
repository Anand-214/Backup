 #include"postfix.h"
								//function body 
void infix_postfix(char infix[],char postfix[])
{
							//local variable declaration
	int top = -1,j=0,i;
	char str[SIZE],symbol;
	top++;
	str[top] = '#';
							//loop run till string reach null
	for(i = 0; i < strlen(infix); i++)
	{
							//stroe infix string character in symbol 
		symbol = infix[i];
									//compare priority 
		while(compare(str[top]) > priority(symbol))
		{
			postfix[j] = str[top--];
			j++;
		}
		if(compare(str[top]) != priority(symbol))
		{
			str[++top] = symbol;
		}
		else
		{
			top--;
		}
	}
	while(str[top] != '#') 
		postfix[j++] = str[top--];
							//insert null at last 
	postfix[j] = '\0';
}

