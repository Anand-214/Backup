#include"postfix.h"
int compare(char symbol)
{
				//stack precedence function F
	switch(symbol)
	{
		case '+':
		case '-':return 2;

		case '*':
		case '/':return 4;

		case '(':return 0;

		case '#':return -1;

		default: return 8;
	}
}
					//input precedence function G
int priority(char symbol)
{
	switch(symbol)
	{
		case ')':return 0;

		case '+':
		case '-':return 1;

		case '*':
		case '/':return 3;

		case '(':return 10;

		default: return 9;

		
	}
}
