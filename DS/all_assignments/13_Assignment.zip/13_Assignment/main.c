/*
date:15/07/2021
assignment name:infix_postfix_eval.c
author name:Perni Venkata Sai Vineeth
*/
#include"postfix.h"


int main()
{
	char infix[SIZE];
	char postfix[SIZE] , choice;
	 
	do
	{
									//get infix expression from user and store it 
		printf("Enter a valid infix expression : ");
		scanf("%s",infix);				//function call 
		infix_postfix(infix,postfix);			//print post_fix expression 
		printf("The postfix expression is : %s \n",postfix);		//post eveluvation function call 
		float result = post_eval(postfix);   		//print result 
		printf("Result of postfix expression is : %g\n",result);	 	
		printf("Do you want to continue(y/n) : ");
		scanf(" %c",&choice);				//continue if choice is y or Y	
	}while ( choice == 'Y' || choice == 'y' );
	return 0;
}
