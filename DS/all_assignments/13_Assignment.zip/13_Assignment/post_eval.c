#include"postfix.h"

float post_eval( char postfix[])
{
	float stack[SIZE],op1,op2,res=0;
	int top=-1,i=0;
	while (postfix [i] != '\0'  )
	{
		if ( my_isdigit ( postfix[i] ))
		{
			top++;
			stack[top] = postfix[i] - 48;
		}
		else 
		{
			op2 = stack[top--];
			op1 = stack[top--];
			switch ( postfix [i] )  // case condition
			{
				case '+' :
					res = op1 + op2;
					break;
				case '-' :
					res = op1 - op2;
					break;
				case '*' :
					res = op1 * op2;
					break;
				case '/' :
					res = op1 / op2;
					break;
			}
			stack[++top] = res;
		}
		i++;
	}
	return stack[top];
}

int my_isdigit(char a) 
{ 
	return (a>=48 && a<=57 )? 1 : 0;
}





