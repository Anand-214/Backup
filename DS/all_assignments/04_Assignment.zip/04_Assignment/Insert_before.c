#include <stdio.h>
#include <stdlib.h>
#include "dlist.h"

int insert_before(dlist **head, dlist **tail, data_t n_data, data_t g_data)
{
	if(*head == NULL) //checking list is empty or not
	{
		return LIST_EMPTY; 
	}

	dlist *temp = *head;

	while(temp != NULL)	//traversing till last node
	{
		if(temp->data == n_data) //comparing node data with user entered data
		{
			dlist *new = malloc(sizeof(dlist));	//allocating memory

			if(new == NULL)	//validation for memory allocation
			{
				return failure;
			}

			new->data = g_data; //inserting data into new node
			new->next = temp;  //updating new node next with next node address 
			new->prev = temp->prev;	//updating new node prev with previous node address
			temp->prev = new;	//next node prev is updating with new node address

			if(new->prev != NULL)	
			{
				new->prev->next = new; //updating previous node next with new node address 
			}
			else
			{
				*head = new; //updating head 
			}
			return success;
		}

		temp = temp->next; //updating temp with next node address
	}	

	return DATA_NOT_FOUND;
}
