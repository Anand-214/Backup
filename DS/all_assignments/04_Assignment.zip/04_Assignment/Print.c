#include "dlist.h"
#include <stdlib.h>
#include <stdio.h>

int Print_list(dlist *head)
{
	if (head == NULL )	//checking list is empty or not
	{
		return LIST_EMPTY;
	}
	else
	{
		while ( head != NULL )
		{
			printf("%d->",head->data);
			head = head->next;
		}
	}
	printf("\n");
}
