#include <stdio.h>
#include <stdlib.h>
#include "dlist.h"

int delete_first(dlist **head,dlist **tail)
{
	if(*head == NULL) //checking list is empty or not
	{
		return LIST_EMPTY;
	}

	(*head) = (*head)->next;	//updating head with next node address

	if(*head == NULL)	//deleting single node if no node exist after
	{
		free(*tail);
		*tail = NULL;
		return success;
	}

	free((*head)->prev); //deleting node
	(*head)->prev = NULL; //updating 2nd node prev with null

	return success;
}
