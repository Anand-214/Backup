#ifndef D_LIST
#define D_LIST

#define LIST_EMPTY 2
#define DATA_NOT_FOUND 3
#define DATA_FOUND 4

typedef int data_t;

typedef struct node 
{
	data_t data;

	struct node *prev;

	struct node *next;

}dlist;

typedef enum
{
	failure,
	success
}status;

int insert_last(dlist **head, dlist **tail, data_t data);

int insert_after(dlist **head, dlist **tail, data_t n_data,data_t g_data);

int insert_before(dlist **head, dlist **tail, data_t n_data,data_t g_data);

int delete_element(dlist **head, dlist **tail,data_t data);

int delete_first(dlist **head,dlist **tail);

int Print_list(dlist *head);

#endif
