#include <stdio.h>
#include <stdlib.h>
#include "dlist.h"

int insert_last(dlist **head, dlist **tail, data_t data)
{
	dlist *new = malloc(sizeof(dlist)); //memory allocation

	if (new == NULL)	//validation for memeory allocation
	{
		return failure;
	}

	new->data = data;	//inserting data into new node
	new->next = NULL;   //intialising new node next with null
	new->prev = *tail;	//intialising new node prev with tail

	if (*head == NULL)	//updating tail and head for new node first node creation
	{
		*head = new;	
		*tail = new;
		return success;
	}

	new->prev->next = new; //updating previous node next with new node address
	*tail = new;	//updating tail

	return success;
}
