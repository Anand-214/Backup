#include <stdio.h>
#include <stdlib.h>
#include "dlist.h"

int delete_element(dlist **head,dlist **tail,data_t data)
{
	if( *head == NULL ) //checking list is empty or not
	{
		return LIST_EMPTY;
	}

	dlist *temp = *head;

	if( ( temp->next == NULL ) && ( temp->data == data ) ) //deleting single node if no node exist after
		return delete_first(head,tail); //function call

	else if( temp->data == data ) //deleting first node 
		return delete_first(head,tail);


	while( temp != NULL ) //traversing till last node
	{
		if( temp->data == data ) //checking if node data matches with user data or not
		{
			temp->prev->next = temp->next; //updating previous node next with next node address of deleted node

			if( temp->next != NULL ) 
				temp->next->prev = temp->prev; //next node prev with previous node address of deleted node 
			else
				temp->prev->next = NULL; //next is updated with null if no node exist after

			free(temp); //deallocating/deleting memory
			return success;
		}
		temp = temp->next; //updating with next node address
	}

	return DATA_NOT_FOUND;
}
