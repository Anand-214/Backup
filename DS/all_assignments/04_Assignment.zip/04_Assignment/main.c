/*
date:28/06/2021
assignment name:
	1.dl_insert_after.c
	2.dl_insert_before.c
	3.dl_delete_element.c
author name:Perni Venkata Sai Vineeth
*/
#include <stdio.h>
#include "dlist.h"
#include <stdlib.h>

int main()
{
	//initialising head and tail with null
	dlist *head = NULL;
	dlist *tail = NULL;

	int choice,ret,data,n_data,g_data;
	char option;

	do
	{

		printf("1. Insert_last\n2. Insert_after\n3. Insert_before\n4. Delete_element\n5. Print\n6. quit\nEnter your choice: ");
		scanf("%d",&choice);

		switch (choice)
		{
			case 1:
				printf("Enter data: ");
				scanf("%d",&data);   //reading data from user

				ret = insert_last(&head, &tail, data); //function call

				if ( ret == failure) //function execution status
					printf("ERROR: Insert at last failed\n");
				else
					printf("data inserted\n");

				break;
			case 2:

				printf("Enter node data: ");
				scanf("%d",&n_data);	//reading existing node data

				printf("Enter new data: ");
				scanf("%d",&g_data);	//reading new data

				ret = insert_after(&head, &tail, n_data, g_data); //function call

				if ( ret == failure)
					printf("ERROR: Insert after failed\n");
				else if(ret == LIST_EMPTY)
					printf("List is empty\n");
				else if(ret == DATA_NOT_FOUND)
					printf("Data not found\n");
				else
					printf("Data inserted\n");

				break;
			case 3:

				printf("Enter node data: ");
				scanf("%d",&n_data);

				printf("Enter new data: ");
				scanf("%d",&g_data);	

				ret = insert_before(&head, &tail, n_data, g_data); //function call 

				if ( ret == failure)
					printf("ERROR: delete before failed\n");
				else if(ret == LIST_EMPTY)
					printf("List is empty\n");
				else if(ret == DATA_NOT_FOUND)
					printf("Data not found\n");
				else
					printf("Data inserted\n");

				break;		
			case 4: 
				printf("Enter data: ");
				scanf("%d",&data);

				ret = delete_element(&head, &tail,data); //function call

				if ( ret == failure)
					printf("ERROR: delete element failed\n");
				else if(ret == LIST_EMPTY)
					printf("List is empty\n");
				else
					printf("Deleted element\n");

				break;

			case 5: 

				ret = Print_list(head);
				
				if(ret == LIST_EMPTY)
					printf("List is empty\n");
				
				break;
			case 6:
				exit(1);
				break;
			default:
				printf("Please enter appropriate choice\n");
		}

		printf("\nDo you want to continue: ");
		getchar();
		scanf("%c",&option);

	}while(option == 'y' || option == 'Y');
}
