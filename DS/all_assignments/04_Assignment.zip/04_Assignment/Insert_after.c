#include <stdio.h>
#include <stdlib.h>
#include "dlist.h"

int insert_after(dlist **head, dlist **tail, data_t n_data, data_t g_data)
{
	if(*head == NULL)
	{
		return LIST_EMPTY; 
	}

	dlist *temp = *head;

	while(temp != NULL)	//traversing till last node
	{
		if(temp->data == n_data)	//checking user data matches with node data or not
		{
			dlist *new = malloc(sizeof(dlist));	//allocating memory

			if(new == NULL)	//validation for memory allocation
			{
				return failure;
			}

			new->data = g_data;	//inserting data into new node
			new->next = temp->next;	//updating new node next with previous node address
			new->prev = new;	
			temp->next = new; //updaing previous node next with new node address

			if(new->next != NULL)	
			{
				new->next->prev = new; //updating next node prev with new node address
			}
			else
			{
				*tail = new;	//updating tail with new
			}
			return success;
		}

		temp = temp->next; //updating with next node address
	}	

	return DATA_NOT_FOUND;
}
