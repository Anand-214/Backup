#include "main.h"

data_type delete_list(dlist **head)
{
    /* checking head is NULL */
    if (*head == NULL)
	return LIST_EMPTY;

    dlist *temp;
    while(*head != NULL)                                
    {
	temp = *head;                                
	*head = (*head) -> next;

	/* freeing temp */                                     
	free(temp);                                     
    }
    return SUCCESS;

}
