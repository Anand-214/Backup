/*
 * Name		  : Sindhu T S
 * Date		  : 02.07.2021
 * Description	  : Write a function to insert & delete data at first and last position. Also to delete the list(DLL).
 * Input & Output :	

 Entered datas are :3 -> 5 -> NULL
 1.insert_at_last
 2.insert_at_begenning
 3.Delete_first
 4.Delete_last
 5.Print list
 6.Delete_list
 7.Exit

 */

#include "main.h"
int main()
{
    data_type choice, status, data;
    dlist *head = NULL, *tail = NULL;  
    char ch;    
    system("clear");

    do            /* continous loop */
    {
	/* Display menu to user */
	printf("1.insert_at_last\n2.insert_at_beginning\n3.Delete_first\n4.Delete_last\n5.Print list\n6.Delete_list\n7.Exit\nEnter the option: ");
	scanf("%d", &choice);
	system("clear");

	/* switch case to perform user choice */
	switch(choice)       
	{
	    case 1: /* insert at last */

		printf("Enter the data :");
		scanf("%d", &data);

		/* function calling to perform operation and to print statements accordingly */
		status = insert_at_last(&head, &tail, data);                

		if (status == 0)
		    printf("Error: Insertion if Failure\n");
		else
		    printf("The data has been inserted successfully\n");
		break;

	    case 2: /* insert at first */

		print(head);
		printf("Enter the data :");
		scanf("%d", &data);

		/* function calling to perform operation and to print statements accordingly */
		status = insert_at_beg(&head, &tail, data);              

		if(status == 0)
		    printf("Error: Insertion if Failure\n");
		else
		    printf("The data has been inserted successfully\n");
		break;

	    case 3: /* delete first */

		print(head);

		/* function calling to perform operation and to print statements accordingly */
		status = delete_first(&head, &tail);                     

		if(status == 0)
		    printf("The data has been deleted successfully\n");
		if(status == 2)
		    printf("LIST IS EMPTY\n");
		break;

	    case 4: /* delete last */

		print(head);

		/* function calling to perform operation and to print statements accordingly */
		status = delete_last(&head, &tail);               

		if(status == 0)
		    printf("The data has been deleted successfully\n");
		if(status == 2)
		    printf("LIST IS EMPTY\n");
		break;

	    case 5: /* print list */
		print(head);                     
		break;

	    case 6: /* delete list */

		/* function calling to perform operation and to print statements accordingly */
		status = delete_list(&head);       

		if(status == 1)
		    printf("SUCCESSFULLY DELETED ALL NODES OF LINKED LIST\n");
		if(status == 2)
		    printf("LIST IS EMPTY\n");

		break;

	    case 7: /* Exit */
		return 1;                           
		break;

	    default:
		printf("ERROR: INVALID OPTION\n");

	}

	printf("Do you want to continue(y/Y) ? "); /* statement to ask continue option to user */
	scanf("\n%c", &ch);
    }while (ch == 'Y' || ch == 'y');
    return 0;
}
