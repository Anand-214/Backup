#include "main.h"

int delete_last(dlist **head, dlist **tail)
{

    /* to check head is null */                                             
    if(*head == NULL)                              
    {
	return LIST_EMPTY;
    }

    /* assigning tail tp prev to tail */
    *tail = (*tail) -> prev;                         

    if(*tail)
    {
	/* freeing tail */
	free((*tail) -> next);
	/* assigning NULL */
	(*tail) -> next = NULL;              
	return SUCCESS;
    }
    /* freeing head */
    free(*head);  
    /* assigning NULL */                              
    *head = NULL;                                 
    return SUCCESS;
}

