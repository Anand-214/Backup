#include"main.h"

data_type insert_at_beg(dlist **head, dlist **tail, data_type data)
{
    /* Dynamic memory allocation for new node */                            
    dlist *new = malloc(sizeof(dlist));                            
    if(new == NULL)                                                
    {
	return FAILURE;
    }

    /* assigning head->next to temporary variable */
    dlist *temp = (*head) -> next;
    new -> data = data;

    /* assigning NULL */
    new -> prev = NULL;

    /* checking tail is NULL */
    new -> next = *head;                                            
    if(*tail == NULL)                                             
    {
	/* make head and tail as new */                      
	*tail = *head = new;                                   
	return SUCCESS;
    }

    /* assigning new to head->prev */                          
    (*head) -> prev = new;                                           
    *head = new;                              
    return SUCCESS;
}


