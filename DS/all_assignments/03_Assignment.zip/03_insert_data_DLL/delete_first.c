#include"main.h"

data_type delete_first(dlist **head, dlist **tail)
{
    /* check the list is empty or not */                                               
    if(*head == NULL)                             
    {
	return LIST_EMPTY;
    }

    /* check the head is null */
    if((*head)->next)                             
    {
	/* assigning the head to temporary variable */
	dlist *temp = *head;                  

	/* freeing the head */
	free(*head);

	/* assigning the head as new address */
	*head = temp -> next; 

	/* head prev is always null */
	(*head) -> prev = NULL;                 
	return SUCCESS;
    }

    /* freeing tail */
    free(*tail);                                  
    *tail = NULL;                                
    *head = NULL;
    return SUCCESS;
}
