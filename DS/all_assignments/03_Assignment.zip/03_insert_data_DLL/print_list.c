#include"main.h"

void print(dlist *head)
{
    if(head == NULL) /* to check the list is empty or not */
    {
	printf("LIST IS EMPTY\n");
    }
    else
    {
	printf("Enterd datas are :");
	while(head != NULL)                
	{
	    printf("%d -> ",head->data); /* to print the data */
	    head = head->next;        /* assigning next address */
	}
    }
    printf("NULL\n");
}
