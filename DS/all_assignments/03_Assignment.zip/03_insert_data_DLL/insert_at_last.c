#include "main.h"

int insert_at_last(dlist **head, dlist **tail, data_type data)
{
    dlist *new = malloc(sizeof(dlist));   /* dynamic memory allocation */

    if(new == NULL) /* to check the memory is allocated or not */
    {
	return FAILURE;
    }
    new->data = data;  /* assigning data */
    new->prev = *tail; /* assigning tail */
    new->next = NULL; /*assigning null */


    if(*tail == NULL) /* to check tail is null */
    {
	*head = *tail = new; /* make head and tail as new */
	return SUCCESS;
    }
    (*tail)->next = new; /* assigning new to tail as next */
    *tail = new;   /* assigning new */
    return SUCCESS;
}
