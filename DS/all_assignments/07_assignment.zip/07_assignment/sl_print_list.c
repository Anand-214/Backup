#include "slist.h"

//Printing the list created 
data_t print_list(slist_t *head)
{
    //If list is empty return list empty
    if ( head == NULL )
    {
	return LIST_EMPTY;
    }
    //If list is not empty the tarverse till last and print the data present at node
    else
    {
	//traversing the list
	while ( head != NULL )
	{
	    printf("%d->",head->data);  //Printing data present at node
	    head = head->link;
	}
	printf("Null\n");
	return SUCCESS;              //returning success after printing
    }
}
