/*
 * Name          : M Supriya
 * Date          : 08.07.2021
 * description   : program to print sorting the elements in the given list
 * input         : input reads from user
 * output        : sorting elements from given list

 */

#include "slist.h"

// main function is to call all the functions 
int main()
{
    slist_t *head=NULL;      // initialisng head with null
    data_t n_data,option,ret; // initialinsg variables
    char oper;                // initialisng character variable
    do
    {
	printf("1.Insert first\n2.Sort\n3.print list\nEnter your choice : "); // take one option from the user 
	scanf("%d",&option);      // rading the input
	switch(option)
	{
	    case 1 :
		printf("Enter the n_data : ");
		scanf("%d",&n_data);
		ret=insert_first(&head,n_data);   // function call will be here
		if ( ret == FAILURE )
		    printf("Memory allocation failure\n");
		break;

	    case 2 :
		ret=sort(&head);                 // function call
		if ( ret == LIST_EMPTY )
		    printf("List is Empty\n");
		break;

	    case 3 :
		print_list (head);
		printf("printing list successfully\n");
		break;

	    default :
		printf("Please Enter the proper option\n");
		break;
	}
	//	ret=print_list(head);
	printf("Do you want to continue [y/n] : ");
	getchar();
	scanf("%c",&oper);
    }while ( oper == 'Y' || oper == 'y' );
    return 0;
}
