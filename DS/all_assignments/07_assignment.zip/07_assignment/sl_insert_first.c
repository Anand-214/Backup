#include "slist.h"

//function to insert the node at first
data_t insert_first(slist_t **head,data_t n_data)
{
    slist_t *new=malloc(sizeof(slist_t));
    if ( new == NULL )                //Checking the new node is created or not
	return FAILURE;
    else
    {
	new->data=n_data;          //Updating newly created not values(data,link)
	new->link=NULL;
	if ( *head == NULL )       //Checking for head is null or not
	{
	    *head = new;       //If present updating newly created node to head and return success
	    return SUCCESS;
	}
	else
	{
	    slist_t *temp=*head;  //If head is not null means inserting new node at first and returning success
	    *head=new;
	    new->link = temp;
	    return SUCCESS;
	}
    }

}
