#ifndef TREE_H
#define TREE_H

#define TREE_EMPTY 2

typedef int data_t;

typedef struct node
{
	data_t data;
	struct node *r_link,*l_link;
}bst_tree;


bst_tree *create_node(data_t data);

bst_tree *insert(bst_tree *root,data_t data);

int inorder_print(bst_tree *root);

#endif
