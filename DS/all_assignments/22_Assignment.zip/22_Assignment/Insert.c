#include <stdio.h>
#include "tree.h"

bst_tree *insert(bst_tree *root,data_t data)
{
	if(root == NULL)
	{
		root = create_node(data);
		return root;
	}
	if(root->data > data)
	{
		root->l_link = insert(root->l_link,data);
	}
	else if(root->data < data)
	{
		root->r_link = insert(root->r_link,data);
	}
	else
	{
		printf("Data already present\n");
	}

	return root;
}
