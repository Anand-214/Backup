/*
date:12/07/2021
assignment name:bst_delete_node.c
author name:Perni Venkata Sai Vineeth
*/
#include <stdio.h>
#include "tree.h"

int main()
{
	int data,choice,status;
	char option;

	bst_tree *root = NULL;
	do
	{
		printf("1. Insert node\n2. Inorder print tree\nEnter your choice\n");
		scanf("%d",&choice);

		switch(choice)         // case condition
		{
			case 1:                                //insert
				printf("Enter node data:");
				scanf("%d",&data);

				root = insert(root,data);

				break;
			case 2:
                                                                //inorder print
				status = inorder_print(root);

				if(status == TREE_EMPTY)
				{
					printf("tree is empty\n");
				}
				break;
			default:
				printf("Please enter appropriate choice\n");
		}

		getchar();
		printf("Do you want to continue(y/Y): ");
		scanf("%c",&option);

	}while(option == 'y' || option == 'Y');

	return 0;
}
