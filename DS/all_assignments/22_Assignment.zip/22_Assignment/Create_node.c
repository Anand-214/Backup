#include <stdio.h>
#include <stdlib.h>
#include "tree.h"


bst_tree *create_node(data_t data)
{
	bst_tree *new = malloc(sizeof(bst_tree));

	new->data = data;
	new->l_link = NULL;
	new->r_link = NULL;
	
	return new;
}
