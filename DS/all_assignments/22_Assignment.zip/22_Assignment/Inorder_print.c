#include <stdio.h>
#include "tree.h"

int inorder_print(bst_tree *root)
{
	if(root == NULL)
	{
		return TREE_EMPTY;
	}

	inorder_print(root->l_link);
	
	printf("%d->",root->data);

	inorder_print(root->r_link);

}
