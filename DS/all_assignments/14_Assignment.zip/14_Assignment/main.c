/*
 * Name		  : Sindhu T S
 * Date		  : 17.07.2021
 * Description	  : Write a function to convert the given infix expression into the prefix form and to evaluate the prefix expression.
 * Input & Output :  

 Enter Infix Input : 2+4*4
 INFO: Postfix Expression ==> +2*44
 INFO: After doing Postfix Evaluation ==> 18 
 
 */

#include<stdio.h>
#include<string.h>

#include "stacklist.h"

int main()
{
    //declaring variables
    char ch;
    float res;
    char str[20];                                            
    do
    {
	printf("Enter Infix Input : ");

	scanf("%s", str);

	//finding infix string length
	int len = strlen(str);                           

	//creating infix array
	char pre_arr[len + 1];                             

	//function call of infix to prefix
	infix_prefix(str, pre_arr);                      

	//printing the prefix output
	printf("INFO: Prefix Expression ==> %s \n", pre_arr);   

	//function call of eveluation
	res = pre_eval(pre_arr);                         

	printf("INFO: After Doing Prefix Evaluation==> %g \n",res);

	printf("Do you want to continue(Y/y) : ");
	getchar();
	scanf("%c", &ch);
    }
    while(ch == 'y' || ch == 'Y');
    return 0;
}
