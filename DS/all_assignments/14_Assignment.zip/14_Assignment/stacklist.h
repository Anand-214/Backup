#ifndef STACKLIST_H
#define STACKLIST_H

//header files
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

//defining macros
#define SUCCESS 0                                        
#define FAILURE -1
#define capacity 10

//function prototypes
void infix_prefix(char infix[], char prefix[]);          
int infix_prec(char ch);
int st_prec(char ch);
int str_rev(char *str);
float pre_eval(char pre[]);

#endif
