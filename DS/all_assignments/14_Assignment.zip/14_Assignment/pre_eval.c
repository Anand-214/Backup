#include "stacklist.h"

float pre_eval( char pre[] )
{
    //declaring variables
    float stack[20], op1, op2, res;
    int top = -1, i = 0;                                    
    //fucntion call of reverse string
    str_rev(pre);
    while( pre[i] != '\0' )
    {
	if( isdigit( pre[i] ) )                      
	{
	    //top increment
	    top++;                             
	    //typecasting char to int
	    stack[top] = pre[i] - '0';          
	}
	else
	{
	    op2 = stack[top--]; //top decrement
	    op1 = stack[top--];                

	    //switch case 
	    switch( pre[i] )                   
	    {
		case '+':
		    res = op1 + op2;
		    break;
		case '-':
		    res = op1 - op2;
		    break;
		case '*':
		    res = op1 * op2;
		    break;
		case '/':
		    res = op1 / op2;
		    break;
	    }
	    //increment of top of stack is stored in result
	    stack[++top] = res;              
	}
	i++;
    }
    return stack[top];                       
}
