#include "stacklist.h"
int infix_prec(char ch)
{
    //switch case 
    switch (ch)                 
    {
	case ')' :
	    return 0;
	    break;
	case '+' :
	case '-' :
	    return 1;
	    break;
	case '*' :
	case '/' :
	    return 3;
	    break;
	case '(' :
	    return 10;
	    break;
	default:
	    return 9;
    }
}
