#include "stacklist.h"

void infix_prefix(char infix[], char prefix[])
{
    //declaring variables
    int top = -1, i, j=0;                            
    char stack[30];
    top++;
    stack[top] = '#';
    //fucntion call of reverse infix string
    str_rev(infix);                                 

    for(i = 0; infix[i] != '\0'; i++)
    {
	while(st_prec(stack[top]) > infix_prec(infix[i]))        
	{
	    prefix[j] = stack[top];
	    //top decrement
	    top--;                                           
	    j++;
	}
	if(st_prec(stack[top]) != infix_prec(infix[i]))            
	{
	    //top increment
	    top++;                                           
	    stack[top]=infix[i];
	}
	else                                                     
	{
	    top--;
	}
    }
    while(stack[top] != '#')
    {
	//assigning top of stack to prefix of j variable
	prefix[j] = stack[top];                                 
	top--;
	j++;
    }
    prefix[j] = '\0';
    //function call of reverse string
    str_rev(prefix);
}


int str_rev( char *str )
{
    int i, j;
    char temp;
    //finding string length
    int n = strlen(str); 	
    for(i = 0, j = n - 1; j >= i ; i++, j--)
    {
	temp = str[i];
	str[i] = str[j];
	str[j] = temp;
    }
}
