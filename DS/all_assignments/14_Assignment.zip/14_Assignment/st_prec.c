#include "stacklist.h"
int st_prec(char ch)
{
    //switch case
    switch(ch)                     
    {
	case '#':
	    return -1;
	    break;
	case '(' :
	    return 0;
	    break;
	case '+' :
	case '-' :
	    return 2;
	    break;
	case '*' :
	case '/' :
	    return 3;
	    break;
	default:
	    return 8;
    }
}
