
#include <stdio.h>                     //standard header file
#include <stdlib.h>

#define SUCCESS 0
#define FAILURE -1                        //define marcos
#define NOELEMENT -2
#define DUPLICATE -3

typedef int data_t;

typedef struct treenode
{
	struct treenode *left;
	data_t data;
	struct treenode *right;
}TreeLink;

/*   crt bst*/
int create_BST(TreeLink **, data_t);

/*print bst*/
void inorder_Traverse(TreeLink * root);
void preorder_Traverse(TreeLink * root);
void postorder_Traverse(TreeLink * root);
/* Compute the number of nodes in a tree
 */
int getTotalNodes(TreeLink * root);

/* Compute the height or maximum depth of a tree
 */
int getTreeHeight(TreeLink * root);



int insert_BST(TreeLink ** root, data_t data);
