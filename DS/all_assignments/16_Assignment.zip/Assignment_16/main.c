/*
Name:Abhishek Khot
Date: 8/7/2021
Assignment name:Assignment_16
Description:WAP for Queue implementation using linked list
input:gcc /Assignment_16$ make
./main.out
Enter the option
 1.Enqueue
 2.Dequeue
 3.Peek_queue
 4.Print_queue
Enter the choice :1
Enter the data to insert in queue:1
Info:Data enqueued is 1
Validated data
Data in queue is 1
do you want to continue(y/n):y
Enter the option
 1.Enqueue
 2.Dequeue
 3.Peek_queue
 4.Print_queue
Enter the choice :1
Enter the data to insert in queue:2
Info:Data enqueued is 2
Validated data
Data in queue is 1 2
do you want to continue(y/n):y
Enter the option
 1.Enqueue
 2.Dequeue
 3.Peek_queue
 4.Print_queue
Enter the choice :1
Enter the data to insert in queue:3
Info:Data enqueued is 3
Validated data
Data in queue is 1 2 3
do you want to continue(y/n):y
Enter the option
 1.Enqueue
 2.Dequeue
 3.Peek_queue
 4.Print_queue
Enter the choice :1
Enter the data to insert in queue:4
Info:Data enqueued is 4
Validated data
Data in queue is 1 2 3 4
do you want to continue(y/n):y
Enter the option
 1.Enqueue
 2.Dequeue
 3.Peek_queue
 4.Print_queue
Enter the choice :2
Data dequeued from the list is 1
Validated data
Data in queue is 2 3 4
do you want to continue(y/n):y
Enter the option
 1.Enqueue
 2.Dequeue
 3.Peek_queue
 4.Print_queue
Enter the choice :3
The peek data is 2
Validated data
Data in queue is 2 3 4
do you want to continue(y/n):y
Enter the option
 1.Enqueue
 2.Dequeue
 3.Peek_queue
 4.Print_queue
Enter the choice :4
Data in queue is 2 3 4
Validated data
Data in queue is 2 3 4
do you want to continue(y/n):n


*/
#include "Queue.h"

int main()
{
    //variable declaration
    char ch;
    int option,data,result;

    queue_t *front = NULL;
    queue_t *rear = NULL;

    do
    {
	//entering the option for operation
	printf("Enter the option\n 1.Enqueue\n 2.Dequeue\n 3.Peek_queue\n 4.Print_queue\n");
	printf("Enter the choice :");
	scanf("%d",&option);

	switch(option)
	{
	    case 1:                             // Function for enqueue operation
		printf("Enter the data to insert in queue:");
		scanf("%d", &data);
		result = ll_enqueue( &front, &rear, data );
		if( result == FAILURE )
		{
		    printf("Error:Failed to insert data\n");
		}
		else
		{
		    printf("Info:Data enqueued is %d\n",data);
		}
		break;
	    case 2:                              //function for dequeue operation
		result = ll_dequeue( &front, &rear, &data );
		if ( result == QUEUE_EMPTY )
		{
		    printf("Error:Queue is empty,failed to remove the data\n");
		}
		break;
	    case 3:                              //function for peek operation
		result = ll_peek( front );
		if( result == QUEUE_EMPTY )
		{
		    printf("Error:Queue is empty,failed to get data\n");
		}
		break;
	    case 4:                            //function for print_queue  operation
		{
		    ll_printqueue( front );
		}
		break;

	    default:
		printf("Error:Invalid option\n");
	}

	                          //check for validation
	printf("Validated data\n");
	ll_printqueue( front );

	                                   //asking to repeat the function
	printf("do you want to continue(y/n):");
	scanf("\n%c",&ch);
    }while( ch == 'y' || ch == 'Y' );
    return 0;
}
