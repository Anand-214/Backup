#include"Queue.h"

void ll_printqueue( queue_t *front )
{   
    //check front is null or not
    if ( front == NULL )
    {
	printf("Queue is empty\n");
    }
    else
    {
	printf("Data in queue is");
	//to print the data
	while ( front != NULL )
	{
	    printf(" %d",front->data);
	    front = front->link;
	}
	printf("\n");
    }
}
