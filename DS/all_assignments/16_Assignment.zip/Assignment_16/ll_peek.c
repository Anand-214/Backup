#include"Queue.h"

int ll_peek( queue_t *front )
{
    //Check front is NULL or not
    if ( front == NULL )
    {
	return QUEUE_EMPTY;
    }
    //To get/view the front value
    else
    {
	printf("The peek data is %d\n",front->data);
    }
}
