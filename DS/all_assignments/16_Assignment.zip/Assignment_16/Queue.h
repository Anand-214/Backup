#ifndef QUEUE_H
#define QUEUE_H

#include<stdio.h>
#include<stdlib.h>

#define SUCCESS 0
#define FAILURE -1
#define QUEUE_EMPTY 3

//structure defintion
typedef int data_t;
typedef struct node
{
    data_t data;
    struct node *link;
}queue_t;

//Function declaration for enqueue
int ll_enqueue( queue_t **, queue_t **, data_t  );

//Function declaration for dequeue
int ll_dequeue( queue_t **, queue_t **, data_t * );

//Function declaration for peek
int ll_peek( queue_t * );

//Function declaration for printqueue
void ll_printqueue( queue_t * );

#endif
