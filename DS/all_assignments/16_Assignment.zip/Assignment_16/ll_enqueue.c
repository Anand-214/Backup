#include"Queue.h"

int ll_enqueue( queue_t **front, queue_t **rear, data_t data )
{   
                             //create a new node
    queue_t *newnode = malloc(sizeof(queue_t));

                             //check if newnode is NULL
    if ( newnode == NULL )
    {
	return FAILURE;
    }

                             //assign data and address to newnode
     newnode->data = data;
    newnode->link = NULL;

                             //make rear and front ptr point to newnode
    if( *front == NULL && *rear == NULL )
    {
	*front = newnode;
	*rear = newnode;
	return SUCCESS;
    }
                             //for next node,assign next node address to newnode
    else
    {
	(*rear)->link = newnode;
	*rear = newnode;
    }
    return SUCCESS;
}

