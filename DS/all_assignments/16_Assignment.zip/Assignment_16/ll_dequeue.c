#include"Queue.h"

int ll_dequeue( queue_t **front, queue_t **rear, data_t *data )
{   
                                  //check front and rear ptr are NULL
    if( *front == NULL && *rear == NULL )
    {
	return QUEUE_EMPTY;
    }	

                         //assign front ptr to temp ptr
    queue_t *temp = *front;

                        //to get the data of temp/front ptr
    *data = (*front)->data;

                         //print the statement for output
    printf("Data dequeued from the list is %d\n",(*front)->data);

                       //incrementing the front ptr to next address
    *front = (*front)->link;

                    //deleting the data
    free(temp);

    return SUCCESS;

}
