#ifndef QUEUE_H
#define QUEUE_H

#include<stdio.h>
#include<stdlib.h>

#define SUCCESS 0
#define QUEUE_FULL 2
#define QUEUE_EMPTY 3
#define size 8

//structure defintion
typedef int data_t;
typedef struct queue
{
    data_t data[size];
    int rear;
    int front;
}queue_t;

//declaration for enqueue function
int enqueue( queue_t *, data_t );

//declaration for dequeue function
int dequeue( queue_t *, data_t * );

//declaration for peek queue function
int peek_queue( queue_t * );

//declaration for print queue function
void print_queue( queue_t * );

#endif
