/*
date: 7 july 2021
Assignment name:Assignment_15
Author name:Shresth kumar
Description:WAP for Queue implementation using arrays
*/
#include"Queue.h"

void print_queue( queue_t *queue )
{   
    //check  wether queue is empty or not
    if ( queue->rear == -1 && queue->front == -1 )
    {
	printf("Queue is empty\n");
    }
    //to print the queue data
    else
    {
	printf("Queue data is");
	for ( int i = queue->front; i <= queue->rear; i++ )
	{
	    printf(" %d",queue->data[i]);
	}
	printf("\n");
    }
}
