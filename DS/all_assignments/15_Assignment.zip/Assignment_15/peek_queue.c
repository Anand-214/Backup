/*
date: 7 july 2021
Assignment name:Assignment_15
Author name:Shresth kumar
Description:WAP for Queue implementation using arrays
*/
#include"Queue.h"

int peek_queue( queue_t *queue )
{   
    //check the condition  if the queue is empty or not
    if (queue->rear == -1 && queue->front == -1 )
    {
	return QUEUE_EMPTY; 
    }
    //print the peek data
    else
    {
	printf(" peek data is  %d\n",queue->front[queue->data]);
    }
}
