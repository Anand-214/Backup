/*
date: 7 july 2021
Assignment name:Assignment_15
Author name:Shresth kumar
Description:WAP for Queue implementation using arrays
*/
#include"Queue.h"

int dequeue( queue_t *que, data_t *data )
{   
    //condition to queue list is empty
    if( que->rear == -1 && que->front == -1 )
    {
	return QUEUE_EMPTY;
    }
    //if rear == front,only 1 data left in stack,will return the ptrs to -1 
    else if ( que->rear == que->front )
    {
	que->front = -1;
	que->rear = -1;
    }
    //increment the front,after removing data 
    else
    {
	printf("Info:dequeued data is %d\n", que->data[que->front]);
	(que->front)++;
    }
    return SUCCESS;
}
