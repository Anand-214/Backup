
/*
date: 7 july 2021
Assignment name:Assignment_15
Author name:Shresth kumar
Description:WAP for Queue implementation using arrays
input:gcc /Assignment_15$ make
./main.out
Enter the option
 1.Enqueue
 2.Dequeue
 3.Peek_Queue
 4.Print_Queue
Enter the choice :1
Enter the data to insert in queue:1
Info:data enqueued is 1
Validated data
Queue data is 1
do you want to continue(y/n):y
Enter the option
 1.Enqueue
 2.Dequeue
 3.Peek_Queue
 4.Print_Queue
Enter the choice :1
Enter the data to insert in queue:2
Info:data enqueued is 2
Validated data
Queue data is 1 2
do you want to continue(y/n):y
Enter the option
 1.Enqueue
 2.Dequeue
 3.Peek_Queue
 4.Print_Queue
Enter the choice :1
Enter the data to insert in queue:3
Info:data enqueued is 3
Validated data
Queue data is 1 2 3
do you want to continue(y/n):y
Enter the option
 1.Enqueue
 2.Dequeue
 3.Peek_Queue
 4.Print_Queue
Enter the choice :1
Enter the data to insert in queue:4
Info:data enqueued is 4
Validated data
Queue data is 1 2 3 4
do you want to continue(y/n):y
Enter the option
 1.Enqueue
 2.Dequeue
 3.Peek_Queue
 4.Print_Queue
Enter the choice :1
Enter the data to insert in queue:5
Info:data enqueued is 5
Validated data
Queue data is 1 2 3 4 5
do you want to continue(y/n):y
Enter the option
 1.Enqueue
 2.Dequeue
 3.Peek_Queue
 4.Print_Queue
Enter the choice :2
Info:dequeued data is 1
Validated data
Queue data is 2 3 4 5
do you want to continue(y/n):y
Enter the option
 1.Enqueue
 2.Dequeue
 3.Peek_Queue
 4.Print_Queue
Enter the choice :3
 peek data is  2
Validated data
Queue data is 2 3 4 5
do you want to continue(y/n):y
Enter the option
 1.Enqueue
 2.Dequeue
 3.Peek_Queue
 4.Print_Queue
Enter the choice :4
Queue data is 2 3 4 5
Validated data
Queue data is 2 3 4 5
do you want to continue(y/n):n


*/
#include "Queue.h"

int main()
{
    //variable declaration
    char ch;
    int choice,data,result;
 
 queue_t *queue = malloc(sizeof(queue_t));
 queue->front = -1;
 queue->rear = -1;   

    do
    {
	//entering the option for operation
	printf("Enter the option\n 1.Enqueue\n 2.Dequeue\n 3.Peek_Queue\n 4.Print_Queue\n");
	printf("Enter the choice :");
	scanf("%d",&ochoice);

	switch(choice)
	{
	    case 1: // Function for Enqueue operation
		printf("Enter the data to insert in queue:");
		scanf("%d", &data);
		result = enqueue( queue, data );
		if( result == QUEUE_FULL )
		{
		    printf("Error:Queue is full,Failed to insert data\n");
		}
		break;
	    case 2: //function for dequeue operation
		result = dequeue( queue, &data );
		if ( result == QUEUE_EMPTY )
		{
		    printf("Error:Queue is empty,failed to remove the data\n");
		}
		break;
	    case 3: //function for peek operation
		result = peek_queue( queue );
		if( result == QUEUE_EMPTY )
		{
		    printf("Error:Stack is empty,failed to get data\n");
	        }
		break;
	    case 4: //function for peep operation
		{
		    print_queue( queue );
		}
		break;

	    default:
		printf("Error:Invalid option\n");
	}

	//check for validation
	printf("Validated data\n");
	print_queue( queue );

	//asking the user if he wants to continue or not
	printf("do you want to continue(y/n):");
	scanf("\n%c",&ch);
    }while( ch == 'y' || ch == 'Y' );
    return 0;
}
