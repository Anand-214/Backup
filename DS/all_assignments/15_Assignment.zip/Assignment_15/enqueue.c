/*
date: 7 july 2021
Assignment name:Assignment_15
Author name:Shresth kumar
Description:WAP for Queue implementation using arrays
*/
#include"Queue.h"

int enqueue( queue_t *queue, data_t data )
{
    //check list is full or not
    if( queue->rear == size-1 )
    {
	return QUEUE_FULL;
    }
    //increment the both rear and front to 0th index from -1
    else if ( queue->front == -1 && queue->rear == -1 )
    {
	(queue->rear)++;
	(queue->front)++;
	//after increment add the data to queue
	queue->data[queue->rear] = data;
    }
    //increment rear to next position and add data
    else
    {
	(queue->rear)++;
	queue->data[queue->rear] = data;
    }
    printf("Info:data enqueued is %d\n",data);
    return SUCCESS;
}

