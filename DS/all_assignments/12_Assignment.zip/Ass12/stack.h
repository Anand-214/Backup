#include <stdio.h>              //standard header file
#include <stdlib.h>

#define SUCCESS 0
#define FAILURE -1                  //defien macros
#define STACKEMPTY 1
#define STACKFULL 2

typedef int data_t;

typedef struct snode
{
	data_t data;
	struct snode *link;
}SLink;


typedef struct
{
	SLink *top;
}Stack;


//push operation
int push(Stack *, data_t);
//pop operation
int pop(Stack *, data_t *);
//peep opertion
int peep(Stack);
//peek operation
int peek(Stack);
