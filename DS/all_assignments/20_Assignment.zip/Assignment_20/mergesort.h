#ifndef MERGESORT_H
#define MERGESORT_H

#include<stdio.h>
#include<stdlib.h>

//function definition to print array
int print_array(int arr[],int );

//function for merge sort
int merge_sort(int arr[], int, int );

//function for merge
int merge(int arr[], int , int );

#endif
