/*
date: 7 july 2021
Assignment name:Assignment_20
Author name:Shresth kumar
Description:WAP to sort given array using Merge sort
*/
#include"mergesort.h"


int print_array(int arr[], int data)
{
    //for loop to run till the last index value
    for(int i = 0; i < data; i++)
	printf(" %d", arr[i]); //print the array
    printf("\n");
}
