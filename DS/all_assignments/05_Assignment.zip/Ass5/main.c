/*
Name  :- Lokesh A Devghare
Date  :- 3/06/2021
Input :- take from user
Output :- output will be display on screen.
*/


#include "slist.h"                                        //local header file

int main()                                               //main function
{
		SLink *head = NULL;
		SLink *ahead = NULL;
		SLink *bhead = NULL;

		int data, a_data, result, index;                       //declear variable
		int choice;
		char option;
		int aListElement, bListElement, i;

		do
		{
				//display on screen for choice
				printf("Enter the option:\n");
				printf("1. Insert At Last\n");	
				printf("2. Insert At First\n");	
				printf("3. Find mid\n");	
				printf("4. get nth last\n");	
				printf("Choice: ");
				scanf("%d", &choice);

				switch(choice)
				{
						case 1:      //for insert at last
								printf("Enter the element to be inserted at last: ");
								scanf("%d", &data);
								result = insert_at_last(&head, data);
								(result == SUCCESS)? printf("insert_at_last SUCCESS\n"): printf("insert_at_last FAILURE\n") ;

								break;
						case 2:    //for insert at last
								printf("Enter the element to be inserted at First: ");
								scanf("%d", &data);
								result = insert_at_first(&head, data);
								(result == SUCCESS)? printf("insert_at_first SUCCESS\n"): printf("insert_at_first FAILURE\n") ;

								break;
						case 3: //for find mid node
								result = find_mid(head);
								if (result == EMPTYLIST)
								{
										printf("List is empty\n");
										break;
								}
								(result == FAILURE)? printf("find_mid FAILURE.\n"): printf("mid value is: %d\n", result);

								break;
						case 4: //for get nth last
								printf("Enter the index value to get that value [starts from 0]: ");
								scanf("%d", &index);	
								result = getNth(head, index);
								if (result == NOELEMENT)
								{
										printf("Index out of bound\n");
										break;
								}
								else if (result == EMPTYLIST)
								{
										printf("List is empty\n");
										break;
								}
								(result == FAILURE)? printf("getNth FAILURE.\n"): printf("Nth value is: %d\n", result);

								break;
						default:
								printf("Invalid entry.\n");
								break;
				}

				//check the list for validating
				print_list(head);

				/* check for continue */
				printf("Continue (y/n): ");
				scanf("\n%c", &option);

				if ( option == 'y' )
				{
						continue;
				} else
				{
						break;
				}

		} while (1);

		return 0;
}

