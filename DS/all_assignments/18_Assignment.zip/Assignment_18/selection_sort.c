/*
date: 7 july 2021
Assignment name:Assignment_18
Author name:Shresth kumar
Description:WAF to sort given array using bubble sort, insertion sort and selection sort
*/
#include"sort.h"

//selection sort function
int selection_sort(int size, int *arr)
{
    int min;
    for(int i = 0; i < size; i++)
    {   
	min = i;
	for(int j = i; j < size; j++)
	{
	    if(arr[min] > arr[j]) //if condition to compare the indexes of arrays
		min = j;
	}
	//swap operation
	int temp = arr[i];
	arr[i] = arr[min];
	arr[min] = temp;
    }
    return SUCCESS;
}
