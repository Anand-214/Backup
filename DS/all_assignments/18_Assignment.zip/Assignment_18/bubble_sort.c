/*
date: 7 july 2021
Assignment name:Assignment_18
Author name:Shresth kumar
Description:WAF to sort given array using bubble sort, insertion sort and selection sort
*/
#include"sort.h"

//bubble sort function
int bubble_sort(int size, int *arr)
{
    //declare variable
    int i, j, temp;
    for(i = 0; i < size; i++)
    {   
	for(j = 0; j < size - 1 - i; j++)
	{
	    if(arr[j] > arr[j+1]) //if condition to compare indexes of array
	    {
	        //swap operation
		temp = arr[j];
		arr[j] = arr[j+1];
		arr[j+1] = temp;
	    }
	}
    }  
    return SUCCESS; 
}
