/*
date: 7 july 2021
Assignment name:Assignment_18
Author name:Shresth kumar
Description:WAF to sort given array using bubble sort, insertion sort and selection sort
input:gcc /Assignment_18$ make
./main.out
Enter the option
 1.Bubble Sort
 2.Insertion Sort
 3.Selection Sort
Enter your choice : 1
Enter the size of the array : 5
Enter the 5 array elements : 9 4 3 7 1

INFO : The array is sorted using bubble sort.
 Array after sort : 1 3 4 7 9 

Do you want to continue (y/n) : y
 Enter the option
 1.Bubble Sort
 2.Insertion Sort
 3.Selection Sort
Enter your choice : 2
Enter the size of the array : 5
Enter the 5 array elements : 9 7 2 4 6

INFO : The array is sorted using Insertion sort.
 Array after sort : 2 4 6 7 9 

Do you want to continue (y/n) : y
 Enter the option
 1.Bubble Sort
 2.Insertion Sort
 3.Selection Sort
Enter your choice : 3
Enter the size of the array : 5
Enter the 5 array elements : 3 1 8 9 4

INFO : The array is sorted using Selection sort.
 Array after sort : 1 3 4 8 9 

Do you want to continue (y/n) : n


*/
#include"sort.h"
int main()
{
    //declare variables
    int option, size, result;
    char ch;
    do
    {
	printf(" Enter the option\n 1.Bubble Sort\n 2.Insertion Sort\n 3.Selection Sort\nEnter your choice : ");
	scanf("%d", &option);  

	printf("Enter the size of the array : ");
	scanf("%d", &size);   //read for size of the array
	int arr[size];       //array declaration
	printf("Enter the %d array elements : ", size);
	//scanning array elements
	for(int i = 0; i < size; i++)
	{
	    scanf("%d", &arr[i]);
	}

	switch(option)
	{
	    case 1:{   //Function for bubble sort
		       result = bubble_sort(size, arr); 
		       if(result == SUCCESS)
		       {
			   printf("\nINFO : The array is sorted using bubble sort.\n Array after sort : ");
			   print_array(arr, size); //Print array function call
		       }
		       else
			   printf("\nINFO : bubble sort failed.\n");
		   }
		   break;

	    case 2:{   //Function for insertion sort

		       result = insertion_sort(arr, size); //Insertion sort Function call
		       if(result == SUCCESS)
		       {
			   printf("\nINFO : The array is sorted using Insertion sort.\n Array after sort : ");
			   print_array(arr, size); //Print array function call
		       }
		       else
			   printf("\nINFO : Insertion sort failed.\n");
		   }
		   break;

	    case 3:{   //Function for selection sort

		       result = selection_sort(size, arr); //Selection sort Function call
		       if(result == SUCCESS)
		       {
			   printf("\nINFO : The array is sorted using Selection sort.\n Array after sort : ");
			   print_array(arr, size); //Print array function call
		       }
		       else
			   printf("\nINFO : Selection sort failed.\n");
		   }
		   break;


	    default:
		   printf("\nERROR : Invalid choice.\n");
	}
	//Asking to repeat the functions
	printf("\nDo you want to continue (y/n) : ");
	scanf("\n%c", &ch);             
    }while( ch == 'y' || ch == 'Y'); 
}
