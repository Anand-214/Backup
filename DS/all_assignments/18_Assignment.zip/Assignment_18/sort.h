#ifndef SORT_H
#define SORT_H


#include<stdio.h>


#define SUCCESS 1


//function declaration for insertion sort
int insertion_sort(int *, int);

//function declaration for bubble sort
int bubble_sort(int, int *);

//function declaration for selection sort
int selection_sort(int, int *);

//function declaration for print array
void print_array(int *, int);



#endif
