/*
date: 7 july 2021
Assignment name:Assignment_18
Author name:Shresth kumar
Description:WAF to sort given array using bubble sort, insertion sort and selection sort
*/
#include"sort.h"

//insert sort function
int insertion_sort(int *arr, int size)
{
    
    for(int i = 1; i < size; i++)
    {   
	int j = i - 1;
	int key = arr[i];
	while(j >= 0 && key < arr[j]) //Loop to shift values
	{
	    arr[j + 1] = arr[j];
	    j--;
	}
	arr[j + 1] = key;
    }   
    return SUCCESS;
}
