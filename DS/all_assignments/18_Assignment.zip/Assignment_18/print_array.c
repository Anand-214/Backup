/*
date: 7 july 2021
Assignment name:Assignment_18
Author name:Shresth kumar
Description:WAF to sort given array using bubble sort, insertion sort and selection sort
*/
#include"sort.h"

//print array function
void print_array(int *arr, int size)
{
    for(int i = 0; i < size; i++) //Run loop till end of the array
    {
	printf("%d ", arr[i]);
    }
    printf("\n");
}
