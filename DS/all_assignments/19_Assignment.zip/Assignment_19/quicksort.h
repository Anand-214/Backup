#ifndef QUICKSORT_H
#define QUICKSORT_H

#include<stdio.h>
#include<stdlib.h>

//function definition to print array
int print_array(int arr[],int size);

//function definition for quick sort
int quick_sort(int arr[],int low,int high);

//function definition for partition 
int partition(int arr[],int low,int high);

//function definition for swap
void swap(int *a,int*b);

#endif
