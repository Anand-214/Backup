/*
date: 7 july 2021
Assignment name:Assignment_19
Author name:shresth kumar
Description:WAP to sort given array using Quick sort
input:gcc /Assignment_19$ make
*/
#include"quicksort.h"


int print_array(int arr[], int data)
{
    //for loop to run till the last index value
    for(int i = 0; i < data; i++)
	printf(" %d", arr[i]); //print the array
    printf("\n");
}
