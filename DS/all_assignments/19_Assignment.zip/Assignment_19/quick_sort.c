/*
date: 7 july 2021
Assignment name:Assignment_19
Author name:shresth kumar
Description:WAP to sort given array using Quick sort
input:gcc /Assignment_19$ make
*/
#include"quicksort.h"


void swap( int *a, int *b)
{
    //swap function
    int t = *a;
    *a = *b;
    *b = t;
}

int partition(int arr[], int down, int up)
{
    //assign variable
    int pivot = arr[down];
    int left = down;
    int right;
    //run loop till last element
    for(right = down + 1; right <= up; right++)
    {
	if(arr[right] <  pivot) //compare arr[right] < pivot
	{
	    left++; //if its less,increment left 
	    if(left != right) //check left and right should not be equal
		swap(&arr[right], &arr[left]); //swap the values
	}
    }
    swap(&arr[down], &arr[left]);
    return left;
}

int quick_sort(int arr[], int down, int up)
{
    if(down < up)
    {
	int div = partition(arr, down, up);
	quick_sort(arr, down, div-1); //quick sort for left sublist
	quick_sort(arr, div+1, up); //quick sort for right sublist
    }
}
