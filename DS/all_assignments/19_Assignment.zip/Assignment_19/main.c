/*
date: 7 july 2021
Assignment name:Assignment_19
Author name:Abdulkhadar
Description:WAP to sort given array using Quick sort
input:gcc /Assignment_19$ make
./main.out
Enter the size of array: 10
Enter the array value:2 5 8 7 4 1 3 6 9 0
 0 1 2 3 4 5 6 7 8 9
do you want to continue(y/n):n

*/
#include"quicksort.h"

int main()
{
    //variable declaration
    int size;
    char ch;
    do
    {
        //print the input statement for size
	printf("Enter the size of array: ");
	scanf("%d", &size);

       //assign array
	int arr[size];

        //statement for array input
	printf("Enter the array value:");
	for(int i = 0; i < size; i++)
	    scanf("%d", &arr[i]);

	quick_sort(arr, 0, size - 1); //call function
	print_array(arr, size);    //call print function
	printf("do you want to continue(y/n):");
	scanf("\n%c", &ch);
    }while( ch == 'y' || ch == 'Y' );
    return 0;
}

