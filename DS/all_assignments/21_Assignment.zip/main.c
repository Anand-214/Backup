/*
Name: MOHAMMAD SHARIF
Assigment: WAF to search given data and to find max data node from the BST
Date: 11/07/2021
 */
#include "tree.h"                                //local header file
int main()                                              //main function
{
    int result, data;
    int choice, i = 0;                                   //declear variable
    char option;
    TreeLink * root = NULL;

    do
    {

	printf("Enter the option:\n");
	printf("1. create BST\n");	
	printf("2. insert BST\n");	
	printf("3. in order Traversal\n");	
	printf("4. pre order Traversal\n");	                 //choice for user
	printf("5. post order Traversal\n");
	printf("6. search data in BST\n");
	printf("7. Find minimum most data in BST\n");
	printf("8. Find maximum most data in BST\n");
	printf("Choice: ");
	scanf("%d", &choice);

	switch(choice)
	{
	    case 1: //for creat element
		printf("Enter the element to be inserted with first node as root: ");
		scanf("%d", &data);
		result = create_BST(&root, data);
		(result == SUCCESS)? printf("create_BST SUCCESS\n"): printf("create_BST FAILURE\n") ;
		if (result == DUPLICATE)
		{
		    printf("Duplicate found\n");
		}

		break;
	    case 2: //for insert element
		printf("Enter the element to be inserted with first node as root: ");
		scanf("%d", &data);
		result = insert_BST(&root, data);
		(result == SUCCESS)? printf("create_BST SUCCESS\n"): printf("create_BST FAILURE\n") ;
		if (result == DUPLICATE)
		{
		    printf("Duplicate found\n");
		}


	    case 3: //in order print
		inorder_Traverse(root);	
		printf("\n");

		break;

	    case 4: //in pre order print
		preorder_Traverse(root);	
		printf("\n");	
		break;

	    case 5: // in post order print
		postorder_Traverse(root);	
		printf("\n");	
		break;

	    case 6: //element to search
		printf("Enter the element to be searched: ");
		scanf("%d", &data);
		result = search_BST(root, data);
		(result == SUCCESS)? printf("search_BST SUCCESS.\nKey found\n"): printf("search_BST FAILURE\n") ;
		if (result == NOELEMENT)
		{
		    printf("NO ELEMENT found\n");
		}

		break;

	    case 7: //find Min
		result = findMin_BST(root);
		if (result == NOELEMENT)
		{
		    printf("NO ELEMENT found\n");
		    break;
		}
		printf("Minimum most Node is: %d\n", result);	

		break;

	    case 8:  //find max
		result = findMax_BST(root);
		if (result == NOELEMENT)
		{
		    printf("NO ELEMENT found\n");
		    break;
		}
		printf("Maximum most Node is: %d\n", result);	

		break;

	    default:
		printf("Invalid entry.\n");
		break;
	}

	/* check for continue */
	printf("Do you want to Continue (y/n): \n");
	scanf("\n%c", &option);

	if (option == 'y' || option == 'Y')
	{
	    continue;
	} else
	{
	    break;
	}

    } while (1);

    return 0;
}
