/*
 * File:   main.c
 */

#include <xc.h>
#include "main.h"
#include "adc.h"
#include "clcd.h"
#include <math.h>
#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)

void display( float adc_reg_val_2)
{
    //display current temperature in line2 clcd
    char buff[3];
    int i;
    clcd_print("Temperature", LINE2(0));
    
   //convert integer value to ascii value and display it on clcd
    clcd_print(buff, LINE2(12));
    clcd_putch(0xDF,LINE2(14));
    clcd_putch('C',LINE2(15));

}

static void init_config(void) {
    //clcd init
    init_clcd();
    //adc init
    init_adc();
    //required init in clcd
    clcd_print("LM35 Temp Sensor", LINE1(0));

}

void main(void) {
    unsigned short adc_reg_val, adc_reg_val_cpy = 0;
    float temp;
    init_config();

    while (1) {
        /*reading LM35 sensor*/
        adc_reg_val = read_adc(select the channel connected to temperature sensor);
        if(adc_reg_val_cpy != adc_reg_val)
        {
           adc_reg_val_cpy = adc_reg_val;
        /*converting voltage to millivolts and then converting to temperature  */
            temp = (conversion formula);

           //call the function to display temperature
            display(temp);
        }
    }
    return;
}
