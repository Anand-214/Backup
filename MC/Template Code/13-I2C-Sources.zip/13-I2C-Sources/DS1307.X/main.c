/*
 * File:   main.c
 */

#include <xc.h>
#include "i2c.h"
#include"ds1307.h"
#include "clcd.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)

static void display_time(unsigned char *clock_reg)
{
    /* To store the time in HH:MM:SS format */
    char time[9];
    
    time[0] = ((clock_reg[0] >> 4) & 0x03) + '0';
    time[1] = (clock_reg[0] & 0x0F) + '0';
    time[2] = ':';
    time[3] = ((clock_reg[1] >> 4) & 0x07) + '0';
    time[4] = (clock_reg[1] & 0x0F) + '0';
    time[5] = ':';
    time[6] = ((clock_reg[2] >> 4) & 0x07) + '0';
    time[7] = (clock_reg[2] & 0x0F) + '0';
    time[8] = '\0';
    
    clcd_print(time, LINE2(4));
}

static void get_time(unsigned char *clock_reg)
{
    clock_reg[0] = read_ds1307(HOUR_ADDR);
    clock_reg[1] = read_ds1307(MIN_ADDR);
    clock_reg[2] = read_ds1307(SEC_ADDR);
}

static void init_config(void) {
    init_i2c(100000);
    init_ds1307();
    
    init_clcd();
    clcd_print("  DS1307  TEST  ", LINE1(0));
}

void main(void) {
    unsigned char clock_reg[3];
    
    init_config();

    while (1) {
        get_time(clock_reg);
        display_time(clock_reg);
    }
    
    return;
}
