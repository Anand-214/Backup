/* 
 * File:   main.h
 * Author: CFT
 *
 * Created on 22 April, 2020, 11:03 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#define LED7                RD7

#define LED_ARRAY1          PORTD
#define LED_ARRAY1_DDR      TRISD

extern unsigned int req_time;

#endif	/* MAIN_H */

