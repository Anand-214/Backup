/* 
 * File:   timers.h
 * Author: gk
 *
 * Created on May 15, 2020, 3:09 PM
 */

#ifndef TIMERS_H
#define	TIMERS_H

void init_timer0(void);

#endif	/* TIMERS_H */

