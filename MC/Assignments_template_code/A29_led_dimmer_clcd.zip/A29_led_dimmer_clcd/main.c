


#include <xc.h>
#include "main.h"
#include "timers.h"
#include "matrix_keypad.h"
#include "clcd.h"
#pragma config WDTE = OFF      // Watchdog Timer ~Enable bit (WDT ~enabled)

unsigned char duty_cycle = 0;
int pos=0;

void software_pwm (unsigned char key)
{
    static unsigned int wait = 0;
    char block=??;                        
    char clear=??;                         
    
    if (!wait--)
    {
       wait = 500;

            
        if (key == 1)                  
        {
            if (duty_cycle != PERIOD)
            {
                duty_cycle=duty_cycle+10;  /*increase duty cycle*/
                
            clcd_putch(block,LINE2(pos++));  /*print the special character*/
            }
        }
        else if (key == 2)
        {
            if (duty_cycle != 0)
            {
                duty_cycle=duty_cycle-10; /*decrease duty cycle*/
                
            clcd_putch(clear,LINE2(pos--));    /*remove special character*/
            }
        }
    }
}

static void init_config(void) 
{
   /*configuring portb (RB7)*/
    
        /*------------*/
    init_clcd();
    init_matrix_keypad();
    init_timer0();
    
    /*Enabling global interrupt*/
    GIE = 1;  
    
    clcd_print("LED BRIGHTNESS",LINE1(0));
}

void main(void) {
    unsigned char key;
    init_config();

    while (1) {
        key = read_matrix_keypad(LEVEL);  //read the key pressed
        software_pwm(key);
        
    }
    return;
}
