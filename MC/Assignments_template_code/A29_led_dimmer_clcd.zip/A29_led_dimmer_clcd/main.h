/* 
 * File:   main.h
 * Author: gk
 *
 * Created on May 9, 2020, 10:43 AM
 */

#ifndef MAIN_H
#define	MAIN_H

#define LED1           RB4
#define  ON            1
#define OFF             0

#define LED_ARRAY1      PORTB
#define LED_ARRAY1_DDR  TRISB

#define PERIOD           100

 //extern unsigned int req_time;
extern unsigned char duty_cycle;
extern char c;
extern int x;

#endif	/* MAIN_H */

