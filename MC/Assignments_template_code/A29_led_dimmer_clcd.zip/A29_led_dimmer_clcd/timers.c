#include<xc.h>

void init_timer0(void)
{   
    /*setting the internal  clock source*/
    T0CS = 0 ;
    
    /*timer Interrupt enable bit*/
    TMR0IE = 1;
    
    /*Assigning prescaler to watchdog*/
    PSA = 1;
    
    TMR0 = 6;
}
