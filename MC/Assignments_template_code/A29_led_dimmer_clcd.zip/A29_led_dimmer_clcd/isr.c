#include<xc.h>
#include"main.h"
#include "clcd.h"
void __interrupt() isr(void)
{

    static unsigned int count = 0;
    if (TMR0IF == 1)
    {
        /*TMR0 reg value + offse count to get 250 ticks +2 for cycle compemsation*/
        TMR0 = TMR0 + 6 + 2;
      
          if (++count <= duty_cycle)   
          {
            LED1 = ON;
          }
          else
          {
              LED1 = OFF;
          }
          if (count == PERIOD)
          {
             count = 0;
          }
        
        
        TMR0IF = 0;
    }
}