#include<xc.h>
#include"main.h"
#include "timers.h"
void __interrupt() isr(void)
{
	static unsigned int count = 0;
	if (TMR0IF == 1)
	{
		/*TMR0 reg value + offse count to get 250 ticks +2 for cycle compemsation*/



		if (++count <= duty_cycle)   
		{                            //on condition
			LED1 = ON;
		}
		else
		{                           //off condition
			LED1 = OFF;
		}
		if (count == PERIOD)
		{                           
			count = 0;
		}


		TMR0IF = 0;
	}
}
