/*
 * File:   main.c
 */


#include <xc.h>
#include "main.h"
#include "adc.h"
#include "timers.h"
#pragma config WDTE = OFF      // Watchdog Timer ~Enable bit (WDT ~enabled)

unsigned char duty_cycle = 0;   //initial duty_cycle
void glow_led(unsigned short adc_reg_val)
{
    static unsigned wait = 0;
    
    if (wait--)
    {
        
        //updtae duty_cycle based on reg value
	
        
    }
    
}

static void init_config(void) {
    LED_ARRAY1 = OFF;
    LED_ARRAY1_DDR = 0x00;
    
    init_adc();
    
    init_timer0();
    
    /* GLobal Interrupt Enable */
    GIE = 1;
}

void main(void) {
    unsigned short adc_reg_val;
    init_config();

    while (1) 
    {
      adc_reg_val = read_adc(); //read adc_reg value
      glow_led(adc_reg_val);
    }
    return;
}
