/* 
 * File:   main.h
 */

#ifndef MAIN_H
#define	MAIN_H

#define LED_ARRAY1_DDR    TRISD
#define LED_ARRAY1        PORTD
#define LED1              RD0
#define ON                1
#define OFF               0

#define PERIOD           100      //(0 - 100) //duty_cycle   = adc/10  // change period to 1023 duty_cycle=adc_vale  

extern unsigned char duty_cycle;


#endif	/* MAIN_H */

