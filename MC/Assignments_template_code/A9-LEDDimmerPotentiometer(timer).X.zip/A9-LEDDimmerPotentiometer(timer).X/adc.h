/* 
 * File:   adc.h
 */

#ifndef ADC_H
#define	ADC_H

unsigned short read_adc(void);
void init_adc(void);

#endif	/* ADC_H */

