/* 
 * File:   main.h
 */

#ifndef MAIN_H
#define	MAIN_H
unsigned int hour=12,minute=0,flag=0;
void init_timer2(void);
#endif	/* MAIN_H */

